
// pp4.add(Box.createVerticalStrut(50));
//pp4.add(Box.createVerticalStrut(200));
package oxoxGame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import java.awt.Font;



public class AdminModify extends Frame implements ActionListener{
   JPanel jpanel, jpnTitle, jpnName, jpnId, jpnPw,jpnPhone,jpnNick, jpnButton;
   JButton jbtnOk,jbtnCancel;
   JTextField tfName,tfId,tfPw,tfPhone,tfNickname;
   JLabel lbTitle, lbName, lbId, lbPw, lbPhone, lbNick;
   Font fontT, fontN;
   String testid=null;
   int k=0;
   int idindex=-3;
   private final String PATH = "../oxoxProj/src/oxox.txt";
   private ArrayList<UiJoindata>list=new ArrayList<UiJoindata>();
   UiJoindata uid;
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	
		if(e.getSource()==jbtnOk) {
			try {
				openMember();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			idSearchIndex();
			modifyMember();
			saveMember();
			JOptionPane.showMessageDialog(null,"�����Ǿ����ϴ�","admin",JOptionPane.PLAIN_MESSAGE);
			this.dispose();
			AdminMember m1=new AdminMember();
			
		}
		
		if(e.getSource()==jbtnCancel) {	
			this.dispose();
			AdminMember m1=new AdminMember();
		}
	}
	public void idSearchIndex() {
		idindex=-3;
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).getId().equals(tfId.getText().trim())) {
				idindex=i;
			}
		}
	}
	public void modifyMember() {
		
		list.get(idindex).setName(tfName.getText().trim());
		list.get(idindex).setPw(tfPw.getText().trim());
		list.get(idindex).setPhone(tfPhone.getText().trim());
		list.get(idindex).setNickname(tfNickname.getText().trim());
				
	}
	public void saveMember() {
		ObjectOutputStream oos=null;
		
		try {
			oos=new ObjectOutputStream(new FileOutputStream(PATH));
			oos.writeObject(list);
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			if(oos!=null)
				try {
					oos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	public void openMember() throws Exception {
		
		ObjectInputStream ois=null;
		try {
			ois=new ObjectInputStream(new FileInputStream(PATH));
			list=(ArrayList<UiJoindata>) ois.readObject();
		} catch (Exception e) {
			// TODO: handle exception
			list=new ArrayList<UiJoindata>();
			try {
				new File(PATH).createNewFile();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally {
			if(ois!=null)ois.close();
		}
	} 
  
public void initPro() {
      jpanel=new JPanel();
      jpanel.setLayout(new BoxLayout(jpanel,BoxLayout.Y_AXIS));
      jpnTitle=new JPanel();
      jpnTitle.setLayout(new FlowLayout(FlowLayout.CENTER,0,20));
      jpnName=new JPanel();
      jpnName.setLayout(new FlowLayout(FlowLayout.LEFT,30,0));
      jpnId=new JPanel();
      jpnId.setLayout(new FlowLayout(FlowLayout.LEFT,28,0));
      jpnPw=new JPanel();
      jpnPw.setLayout(new FlowLayout(FlowLayout.LEFT,30,0));
      jpnPhone=new JPanel();
      jpnPhone.setLayout(new FlowLayout(FlowLayout.LEFT,25,0));
      jpnNick=new JPanel();
      jpnNick.setLayout(new FlowLayout(FlowLayout.LEFT,25,0));
      jpnButton=new JPanel();
      jpnButton.setLayout(new FlowLayout(FlowLayout.CENTER,40,0));
      jbtnOk=new JButton();
      jbtnCancel=new JButton();
      tfName=new JTextField(20);
      tfId=new JTextField(14);
      tfPw=new JPasswordField(20);
      tfPhone=new JTextField(20);
      tfNickname=new JTextField(20);
      lbTitle=new JLabel("ȸ������");
      fontT=new Font("����", Font.BOLD, 25);
      lbName=new JLabel("Name");
      fontN=new Font("����", Font.BOLD, 15);
      lbId=new JLabel("������ ȸ����ID");
      lbPw=new JLabel("  PW");
      lbPhone=new JLabel("Phone");
      lbNick=new JLabel("�г���");
      
      
      
      jpanelinfo();
      titleinfo();
      nameinfo();
      idinfo();
      pwinfo();
      phoneinfo();
      nicknameinfo();
      buttoninfo();
      
      this.add(jpanel);
      
      
   }
   public void jpanelinfo() {
      jpanel.add(jpnTitle);
      jpanel.add(jpnId);
	  jpanel.add(jpnName);
	  jpanel.add(jpnNick);
      jpanel.add(jpnPw);
      jpanel.add(jpnPhone);
      jpanel.add(jpnButton);
      
   }
   public void buttoninfo() {
	   jbtnOk.setText("��  ��");
	   jbtnOk.addActionListener(this);
	   jbtnCancel.setText("��  ��");
	   jbtnCancel.addActionListener(this);
	   jpnButton.add(jbtnOk);
	   jpnButton.add(jbtnCancel);
	   
   }
   public void nicknameinfo() {
	   lbNick.setFont(fontN);
	   jpnNick.add(lbNick);
	   jpnNick.add(tfNickname);
   }
   public void phoneinfo() {
	   lbPhone.setFont(fontN);
	   jpnPhone.add(lbPhone);
	   jpnPhone.add(tfPhone);
   }
   public void pwinfo() {
	   lbPw.setFont(fontN);
	   jpnPw.add(lbPw);
	   jpnPw.add(tfPw);
	   
   }
   public void idinfo() {
	   lbId.setFont(fontN);
	   jpnId.add(lbId);
	   lbId.setForeground(Color.blue);
	   jpnId.add(tfId);
   }
   public void nameinfo() {
	   lbName.setFont(fontN);
	   jpnName.add(lbName);
	   jpnName.add(tfName);
	   
   }
   public void titleinfo() {
	   lbTitle.setFont(fontT);
	   lbTitle.setForeground(Color.black);
	   jpnTitle.add(lbTitle);
   }
   
   public AdminModify() {
	   setTitle("����");
      initPro();
      //initPro();
      this.addWindowListener(new WindowAdapter() {

         @Override
         public void windowClosing(WindowEvent e) {
            // TODO Auto-generated method stub
            dispose();
         }

      });
      this.pack();
      this.setBounds(100, 100, 400, 500);
      this.setVisible(true);
   }

   public static void main(String[] args) {
      new AdminModify();
   }

}