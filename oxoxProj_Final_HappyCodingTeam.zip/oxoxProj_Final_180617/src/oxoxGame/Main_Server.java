package oxoxGame;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

class RoomInfo implements Serializable {

	int nRoom;
	String strRoomName;
	Boolean bPaly;
	ArrayList<UserInfo> userInfoList = new ArrayList<UserInfo>();
	int[] nQuiz = new int[10];
	public int getnRoom() {
		return nRoom;
	}

	public void setnRoomNum(int nRoom) {
		this.nRoom = nRoom;
	}

	public String getStrRoomName() {
		return strRoomName;
	}

	public void setStrRoomName(String strRoomName) {
		this.strRoomName = strRoomName;
	}

	public Boolean getbPaly() {
		return bPaly;
	}

	public void setbPaly(Boolean bPaly) {
		this.bPaly = bPaly;
	}

	public ArrayList<UserInfo> getUserInfoList() {
		return userInfoList;
	}

	public void setUserInfoList(ArrayList<UserInfo> userInfoList) {
		this.userInfoList = userInfoList;
	}

	public RoomInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RoomInfo(int nRoom, String strRoomName, boolean bPaly, ArrayList<UserInfo> userInfoList) {
		super();
		this.nRoom = nRoom;
		this.strRoomName = strRoomName;
		this.bPaly = bPaly;
		this.userInfoList = userInfoList;
	}

	@Override
	public String toString() {
		return "RoomInfo [nRoom=" + nRoom + ", strRoomName=" + strRoomName + ", bPaly=" + bPaly + ", userInfoList="
				+ userInfoList + ", nQuiz=" + Arrays.toString(nQuiz) + "]";
	}



	

}

class UserInfo implements Serializable {

	int nRoom;
	String strRoomName;
	String strID;
	String strNick;

	public int getnRoom() {
		return nRoom;
	}

	public void setnRoom(int nRoom) {
		this.nRoom = nRoom;
	}

	public String getStrRoomName() {
		return strRoomName;
	}

	public void setStrRoomName(String strRoomName) {
		this.strRoomName = strRoomName;
	}

	public String getStrID() {
		return strID;
	}

	public void setStrID(String strID) {
		this.strID = strID;
	}

	public String getStrNick() {
		return strNick;
	}

	public void setStrNick(String strNick) {
		this.strNick = strNick;
	}

	public UserInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "UserInfo [nRoom=" + nRoom + ", strRoomName=" + strRoomName + ", strNick=" + strNick + "]";
	}

}

class ChatMessage implements Serializable {
	int nRoom;
	String strFrom;
	String strTo;
	int nType;
	String strMessage;

	public ChatMessage() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ChatMessage [strFrom=" + strFrom + ", strTo=" + strTo + ", nType=" + nType + ", strMessage="
				+ strMessage + "]";
	}

}

public class Main_Server extends Thread {

	final static public int CHAT = 0;
	final static public int LOGIN = 1;
	final static public int MOVE = 2;
	final static public int START = 3;
	final static public int EXIT = 4;
	final static public int USERLIST = 5;
	final static public int ROOM = 6;

	static final int PORT = 5000;
	private Socket socket;
	private int nUserCount;

	int roomInfoSize = 7;
	ArrayList<Thread_Server> threadList = new ArrayList<Thread_Server>();
	ArrayList<RoomInfo> roomInfoList = new ArrayList<RoomInfo>(7);
	ArrayList<UserInfo> userInfoList = new ArrayList<UserInfo>();

	ObjectOutputStream oos;
	ObjectInputStream ois;
	private String strTemp = "";

	public int getnUserCount() {
		return nUserCount;
	}

	public void setnUserCount(int nUserCount) {
		this.nUserCount = nUserCount;
	}

	public String getStrTemp() {
		return strTemp;
	}

	public void setStrTemp(String strTemp) {
		this.strTemp = strTemp;
	}

	public ArrayList<Thread_Server> getThreadList() {
		return threadList;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		int nCount = 0;
		while (true) {

			try {
				Thread.sleep(1);
				nCount++;
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (nCount % 1000 == 0) {
					for (int i = 0; i < threadList.size(); i++) {
						if (!threadList.get(i).isAlive()) {
							System.out.println(userInfoList.get(i).strNick + " ��������");
							threadList.remove(i);
							userInfoList.remove(i);
						}
					}

					// �ش� �濡 ������ ���ų� ������ �ٸ��� ����
					for (int i = 1; i < roomInfoList.size(); i++) {
						if (!roomInfoList.get(i).strRoomName.equals("���")) {
							if (roomInfoList.get(i).userInfoList.size() == 0) {
								roomInfoList.get(i).strRoomName = "���";
								roomInfoList.get(i).bPaly = false;
							}
						}
					}
				}

				if (nCount > 1000) {

					ArrayList<RoomInfo> roomList = new ArrayList<RoomInfo>();
					for (int i = 0; i < roomInfoList.size(); i++) {
						ArrayList<UserInfo> userList = new ArrayList<UserInfo>();
						RoomInfo room = new RoomInfo();
						room.nRoom = roomInfoList.get(i).nRoom;
						room.bPaly = roomInfoList.get(i).bPaly;
						room.strRoomName = roomInfoList.get(i).strRoomName;

						for (int j = 0; j < roomInfoList.get(i).userInfoList.size(); j++) {
							UserInfo player = new UserInfo();
							player.nRoom = roomInfoList.get(i).userInfoList.get(j).nRoom;
							player.strRoomName = roomInfoList.get(i).userInfoList.get(j).strRoomName;
							player.strID = roomInfoList.get(i).userInfoList.get(j).strID;
							player.strNick = roomInfoList.get(i).userInfoList.get(j).strNick;

							if (i == 0) {
								userList.add(player);
							}
						}
						room.userInfoList = userList;
						roomList.add(room);
					}
					for (int k = 0; k < threadList.size(); k++) {
						try {
							threadList.get(k).sendMessage(roomList);// Room ���� 0:���� 1~6:���ӷ�
							// threadList.get(k).sendMessage(userList);// ���̺�
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					nCount = 0;
				}
			}
		}
	}

	public void roomInit() {
		for (int i = 0; i < roomInfoSize; i++) {
			if (i == 0) {
				roomInfoList.add(new RoomInfo(i, "����", false, userInfoList));
			} else {
				roomInfoList.add(new RoomInfo(i, "���", false, new ArrayList<UserInfo>()));
			}
			System.out.println("roomInit()_:" + roomInfoList.get(i));
		}
	}

	public Main_Server() {

		System.out.println("��������");
		roomInit();
		this.start();

		while (true) {
			try {
				ServerSocket serverSocket = new ServerSocket(PORT);
				socket = serverSocket.accept();
				Thread_Server ost = new Thread_Server(this);

				ost.start();
				threadList.add(ost);
				Thread.sleep(2000);

			} catch (Exception e) {
				// TODO Auto-generated catch block
			}
		}
	}

	public static void main(String[] args) {
		new Main_Server();

	}
}
