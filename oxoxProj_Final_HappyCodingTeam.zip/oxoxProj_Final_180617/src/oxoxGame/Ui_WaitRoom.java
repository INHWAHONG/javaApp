package oxoxGame;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import oxoxGame.Main_Client;

public class Ui_WaitRoom extends Frame implements ActionListener, MouseListener {
	private Color cMain = new Color(255, 228, 0);
	private Color cGame = new Color(255, 255, 0);
	private ImageIcon logo, imgstart, imgcreate;
	private JPanel jpnMain, jpnChat, jpnJtable;
	private JLabel lblogo, lbstartimg,	lbcreateimg;
	private JTextArea jtaWaitChat;
	private JTextField jtfWaitchat;
	private JButton jbtnStart, jbtnCreate, jbtnRoom1, jbtnRoom2, jbtnRoom3, jbtnRoom4, jbtnRoom5, jbtnRoom6;

	private DefaultTableModel model;
	private JScrollPane jspUser, jspChat;
	private JTable jTable;
	private Socket socket;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private Main_Client main_Client;
	private Ui_WaitRoom ui_WaitRoom;
	private Thread_Chat thread_Chat;

	private String roomName;
	private String roomPw;
	private RoomInfo roomInfo = new RoomInfo();
	private UserInfo userInfo = new UserInfo();
	private ChatMessage chatMessage = new ChatMessage();

	private int[] randomInt = new int[10];
	private OxoxZocbo oxoxZocbo = new OxoxZocbo();

	// ������
	private ArrayList<JButton> btnList = new ArrayList<JButton>(6);

	final static public int CHAT = 0;
	final static public int LOGIN = 1;
	final static public int MOVE = 2;
	final static public int START = 3;
	final static public int EXIT = 4;
	final static public int USERLIST = 5;
	final static public int GAMEROOM = 6;

	
	
	public DefaultTableModel getModel() {
		return model;
	}

	public void setRoomInfo(RoomInfo roomInfo) {
		this.roomInfo = roomInfo;
	}

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	public void question() { // ���� �ߺ�����&������ ����� �޼ҵ�
		Random random = new Random();
		for (int j = 0; j < 10; j++) {// ���� 10���̱�
			randomInt[j] = random.nextInt(oxoxZocbo.getJockbo().length);

			for (int n = 0; n < j; n++) {
				if (randomInt[j] == randomInt[n]) {
					j--;
					break;
				}
			}
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		if (jbtnStart == e.getSource()) {
			jbtnStart.setBorderPainted(true);
		}
		if (jbtnCreate == e.getSource()) {
			jbtnCreate.setBorderPainted(true);
		}
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		if (jbtnStart == e.getSource()) {
			jbtnStart.setBorderPainted(false);
		}
		if (jbtnCreate == e.getSource()) {
			jbtnCreate.setBorderPainted(false);
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public class OxoxWaitCreate extends Dialog implements ActionListener, ItemListener {

		JPanel jpanel, jpanel1, jpanel2, jpanel3, jpaneln;
		JTextField tfName, tfPW;
		JLabel lbName, lbPW;
		Font font;
		JButton jbtnOk, jbtnCancel;
		Checkbox cb;

		@Override
		public void itemStateChanged(ItemEvent e) {
			// TODO Auto-generated method stub
			if (e.getStateChange() == ItemEvent.SELECTED) {
				tfPW.setEditable(true);
			}
			if (e.getStateChange() == ItemEvent.DESELECTED) {
				tfPW.setEditable(false);
			}
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			UserInfo userInfo = new UserInfo();
			RoomInfo roomInfo = new RoomInfo();

			if (e.getSource() == jbtnOk) {
				for (int i = 0; i < btnList.size(); i++) {
					if(btnList.get(i).getText().equals(tfName.getText())){
						JOptionPane.showMessageDialog(this, "������ �̸��� ���� �����մϴ�.");
						return;
					}
					if (btnList.get(i).getText().equals("���")) {
						btnList.get(i).setText(tfName.getText());

						userInfo.strID = main_Client.getStrId();
						userInfo.strNick = main_Client.getStrNick();
						userInfo.nRoom = i + 1;
						userInfo.strRoomName = btnList.get(i).getText();
						Ui_WaitRoom.this.userInfo.strID = userInfo.strID;
						Ui_WaitRoom.this.userInfo.strNick = userInfo.strNick;
						Ui_WaitRoom.this.userInfo.nRoom = userInfo.nRoom;
						Ui_WaitRoom.this.userInfo.strRoomName = userInfo.strRoomName;
						roomInfo.userInfoList.add(userInfo);

						try {
							new Ui_GameRoom(ui_WaitRoom, Ui_WaitRoom.this.userInfo);
							oos.writeObject(userInfo);

						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						Ui_WaitRoom.this.dispose();
						OxoxWaitCreate.this.dispose();
						return;
					}
				}
				JOptionPane.showMessageDialog(this, "���� ����á���ϴ�.");
			} else if (e.getSource() == jbtnCancel) {
				OxoxWaitCreate.this.dispose();
			}
		}

		public void initCreate() {
			font = new Font("����", Font.BOLD, 15);
			jpanel = new JPanel();
			jpanel1 = new JPanel();
			jpanel2 = new JPanel();
			jpanel3 = new JPanel();
			jpaneln = new JPanel();

			tfName = new JTextField(20);
			tfPW = new JTextField(20);
			tfPW.setEditable(false);

			jbtnOk = new JButton("Ȯ  ��");
			jbtnOk.addActionListener(this);

			cb = new Checkbox(null);
			cb.addItemListener(this);

			jbtnCancel = new JButton("�� ��");
			jbtnCancel.addActionListener(this);

			lbName = new JLabel("���̸�");
			lbName.setFont(font);
			lbPW = new JLabel("��й�ȣ");
			lbPW.setFont(font);
			this.add(jpanel);
			jpanel.add(jpaneln);
			jpanel.setLayout(new GridLayout(4, 1));
			jpanel.add(jpanel1);
			jpanel1.setLayout(new FlowLayout(FlowLayout.LEFT, 30, 0));
			jpanel.add(jpanel2);
			jpanel2.setLayout(new FlowLayout(FlowLayout.LEFT, 22, 0));
			jpanel.add(jpanel3);
			jpanel3.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 0));
			jpanel1.add(lbName);
			jpanel1.add(tfName);
			jpanel2.add(lbPW);
			jpanel2.add(tfPW);
			jpanel2.add(cb);
			jpanel3.add(jbtnOk);
			jpanel3.add(jbtnCancel);
		}

		public OxoxWaitCreate(Main_Client uiLoginMain) {
			super(uiLoginMain);

			initCreate();
			this.setVisible(true);
			this.setTitle("�����");
			this.setBounds(Ui_WaitRoom.this.getWidth() / 2, Ui_WaitRoom.this.getHeight() / 2 - 200, 400, 400);
			this.setAlwaysOnTop(true);
			;
			this.addWindowListener(new WindowAdapter() {

				@Override
				public void windowClosing(WindowEvent e) {
					OxoxWaitCreate.this.dispose();
				}
			});
		}
	}

	public ArrayList<JButton> getBtnList() {
		return btnList;
	}

	public void setBtnList(ArrayList<JButton> btnList) {
		this.btnList = btnList;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	public Main_Client getUiloginMain() {
		return main_Client;
	}

	public void setUiloginMain(Main_Client uiloginMain) {
		this.main_Client = uiloginMain;
	}

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public String getRoomPw() {
		return roomPw;
	}

	public void setRoomPw(String roomPw) {
		this.roomPw = roomPw;
	}

	public JTextArea getJtaWaitchat() {
		return jtaWaitChat;
	}

	public void setJtaWaitchat(JTextArea jtaWaitchat) {
		this.jtaWaitChat = jtaWaitchat;
	}

	public JScrollPane getJspChat() {
		return jspChat;
	}

	public void setJspChat(JScrollPane jspChat) {
		this.jspChat = jspChat;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		UserInfo userInfo = new UserInfo();

		// ��������
		if (e.getSource() == jbtnStart) {
			for (int i = 0; i < btnList.size(); i++) {
				if (!btnList.get(i).getText().equals("���")) {
					if (btnList.get(i).isEnabled()) {// ������ι�
						userInfo.strID = main_Client.getStrId();
						userInfo.strNick = main_Client.getStrNick();
						userInfo.nRoom = i + 1;
						userInfo.strRoomName = btnList.get(i).getText();
						this.userInfo.strID = userInfo.strID;
						this.userInfo.strNick = userInfo.strNick;
						this.userInfo.nRoom = userInfo.nRoom;
						this.userInfo.strRoomName = userInfo.strRoomName;
						try {
							new Ui_GameRoom(ui_WaitRoom, this.userInfo);
							oos.writeObject(userInfo);
							this.dispose();
							return;
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			}
			JOptionPane.showMessageDialog(this, "���������� ���� �����ϴ�.");
		}
		// �����
		if (e.getSource() == jbtnCreate) {
			new OxoxWaitCreate(main_Client);
			return;
		}

		// ��ư������ ������.
		for (int i = 0; i < btnList.size(); i++) {
			if (e.getSource() == btnList.get(i)) {
				if (btnList.get(i).getText().equals("���")) {
					new OxoxWaitCreate(main_Client);
					return;
				} else {
					userInfo.strID = main_Client.getStrId();
					userInfo.strNick = main_Client.getStrNick();
					userInfo.nRoom = i + 1;
					userInfo.strRoomName = btnList.get(i).getText();
					this.userInfo.strID = userInfo.strID;
					this.userInfo.strNick = userInfo.strNick;
					this.userInfo.nRoom = userInfo.nRoom;
					this.userInfo.strRoomName = userInfo.strRoomName;
					new Ui_GameRoom(ui_WaitRoom, this.userInfo);
					try {
						oos.writeObject(userInfo);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					Ui_WaitRoom.this.dispose();
					return;
				}
			}
		}
	}

	public void jtableUpdate(String[][] strArrTemp) {
		model.setRowCount(0);// �������̺��� �ʱ�ȭ
		// System.out.println(strArrTemp.length);
		for (int i = 0; i < strArrTemp.length; i++) {
			model.addRow(strArrTemp[i]);// 0,���̵�,�г��Ӱ��� �־���
			model.setValueAt(i + 1, i, 0);// 0�ڸ��� �ش����Ǽ������� �ٲ���
			if (userInfo.strNick.equals(strArrTemp[i][2])) {
				jTable.setRowSelectionInterval(i, i);
				jTable.setSelectionBackground(cGame);
			}
		}
	}

	public void userJtbInfo() {// �������̺� �����
		String[] strColumn = { "No", "���̵�", "�г���", "��ġ" };
		model = new DefaultTableModel(null, strColumn);// �⺻ ���̺� ����
		jTable = new JTable(model);
		jTable.setGridColor(cMain);
//		jTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		jTable.setEnabled(false);
		jspUser = new JScrollPane(jTable, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);// jsp�����ֱ�
		jpnJtable.add(jspUser);// �гο� ���ϱ�
	}

	public void initpro() {// ���â ������
		jpnJtable = new JPanel(new BorderLayout());
		jpnJtable.setBounds(900, 200, 350, 600);

		jpnMain = new JPanel(null);
		jpnMain.setBackground(cMain);

		logo = new ImageIcon("../oxoxProj/src/image/logo.png");
		lblogo = new JLabel(logo);
		lblogo.setBounds(50, 0, 400, 200);
		imgstart = new ImageIcon("../oxoxProj/src/image/kkr1.png");
		lbstartimg = new JLabel(imgstart);
		imgcreate = new ImageIcon("../oxoxProj/src/image/KKA1.png");
		lbcreateimg = new JLabel(imgcreate);

		jpnChat = new JPanel(null);
		jpnChat.setBackground(Color.pink);
		jpnChat.setBounds(0, 650, 860, 165);

		jbtnStart = new JButton();
		jbtnStart.setBounds(860, 30, 210, 150);
		jbtnStart.setContentAreaFilled(false);
		jbtnStart.setBorderPainted(false);
		jbtnStart.addMouseListener(this);
		jbtnCreate = new JButton();
		jbtnCreate.setBounds(jbtnStart.getX() + jbtnStart.getWidth(), 30, 210, 150);
		jbtnCreate.setContentAreaFilled(false);
		jbtnCreate.setBorderPainted(false);
		jbtnCreate.addMouseListener(this);

		// 1~6���� ��ġ ����
		jbtnRoom1 = new JButton("����");
		jbtnRoom1.setBounds(0, 200, 430, 150);
		btnList.add(jbtnRoom1);
		jbtnRoom2 = new JButton("ȣ����");
		jbtnRoom2.setBounds(jbtnRoom1.getWidth(), jbtnRoom1.getY(), jbtnRoom1.getWidth(), jbtnRoom1.getHeight());
		btnList.add(jbtnRoom2);
		jbtnRoom3 = new JButton("���Ƹ�");
		jbtnRoom3.setBounds(jbtnRoom1.getX(), jbtnRoom1.getY() + jbtnRoom1.getHeight(), jbtnRoom1.getWidth(),
				jbtnRoom1.getHeight());
		btnList.add(jbtnRoom3);
		jbtnRoom4 = new JButton("�⸰");
		jbtnRoom4.setBounds(jbtnRoom2.getX(), jbtnRoom3.getY(), jbtnRoom1.getWidth(), jbtnRoom1.getHeight());
		btnList.add(jbtnRoom4);
		jbtnRoom5 = new JButton("������");
		jbtnRoom5.setBounds(jbtnRoom1.getX(), jbtnRoom3.getY() + jbtnRoom3.getHeight(), jbtnRoom1.getWidth(),
				jbtnRoom1.getHeight());
		btnList.add(jbtnRoom5);
		jbtnRoom6 = new JButton("������");
		jbtnRoom6.setBounds(jbtnRoom2.getX(), jbtnRoom5.getY(), jbtnRoom1.getWidth(), jbtnRoom1.getHeight());
		btnList.add(jbtnRoom6);

		for (int i = 0; i < btnList.size(); i++) {
			btnList.get(i).addActionListener(this);
			btnList.get(i).setBackground(cMain);
			btnList.get(i).setEnabled(false);
			// btnList.get(i).setContentAreaFilled(false);
		}

		jbtnStart.add(lbstartimg);
		jbtnStart.addActionListener(this);
		jbtnCreate.add(lbcreateimg);
		jbtnCreate.addActionListener(this);
		jpnMain.add(jpnChat);
		jpnMain.add(jbtnRoom6);
		jpnMain.add(jbtnRoom5);
		jpnMain.add(jbtnRoom4);
		jpnMain.add(jbtnRoom3);
		jpnMain.add(jbtnRoom2);
		jpnMain.add(jbtnRoom1);
		jpnMain.add(jbtnCreate);
		jpnMain.add(jbtnStart);
		jpnMain.add(lblogo);

		mainInfo();
		textInfo();
	}

	public void mainInfo() {// ���� ui
		this.add(jpnMain);
		jpnMain.add(jpnJtable);
	}

	public void textInfo() {// ä��âui
		jtaWaitChat = new JTextArea();
		jspChat = new JScrollPane(jtaWaitChat, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jpnChat.add(jspChat);
		jspChat.setBounds(0, 0, jpnChat.getWidth(), jpnChat.getHeight() - 30);
		jtaWaitChat.setBounds(0, 0, jpnChat.getWidth(), jpnChat.getHeight() - 30);
		jtaWaitChat.setEditable(false);
		jtfWaitchat = new JTextField();
		jpnChat.add(jtfWaitchat);
		jtfWaitchat.setBounds(jtaWaitChat.getX(), jtaWaitChat.getHeight(), jtaWaitChat.getWidth(),
				jpnChat.getHeight() - jtaWaitChat.getHeight());
		jtfWaitchat.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				chatMessage = new ChatMessage(); // �г������� �ְ�����.
				chatMessage.nType = CHAT;
//				chatMessage.nRoom = userInfo.nRoom;
				chatMessage.nRoom = 0;
				chatMessage.strFrom = userInfo.strNick;
				if (jtfWaitchat.getText().startsWith("/w")||jtfWaitchat.getText().startsWith("/��")) {
					String[] strSplit = jtfWaitchat.getText().split(" ", 3);
					chatMessage.strTo = strSplit[1];
					chatMessage.strMessage = strSplit[2];
				} else {
					chatMessage.strTo = "ALL";
					chatMessage.strMessage = jtfWaitchat.getText();

				}
				try {
					oos.writeObject(chatMessage);
					// oos.flush();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				jtfWaitchat.setText("");
			}
		});
	}

	public Ui_WaitRoom(Main_Client main_Client) {// ������
		this.main_Client = main_Client;
		this.socket = main_Client.getSocket();
		this.oos = main_Client.getOos();
		this.ois = main_Client.getOis();
		this.ui_WaitRoom = this;
		this.userInfo.nRoom = 0;
		this.userInfo.strID = main_Client.getStrId();
		this.userInfo.strNick = main_Client.getStrNick();

		initpro();
		userJtbInfo();

		this.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub

				if (JOptionPane.showConfirmDialog(Ui_WaitRoom.this, "�����Ͻðڽ��ϱ�??", "", JOptionPane.YES_NO_OPTION) == 0) {
					System.exit(0);
				}
			}

		});
		this.setBounds(100, 100, 1300, 900);
		this.setVisible(true);
		this.setTitle("����");
	}

	public Ui_WaitRoom() {
		initpro();
		userJtbInfo();

		this.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				if (JOptionPane.showConfirmDialog(Ui_WaitRoom.this, "�����Ͻðڽ��ϱ�??", "", JOptionPane.YES_NO_OPTION) == 0) {
					System.exit(0);
				}
			}

		});
		this.setBounds(100, 100, 1300, 900);
		this.setVisible(true);
		this.setTitle("����");
	}

	public static void main(String[] args) {
		new Ui_WaitRoom();
	}
}
