package oxoxGame;

import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ChangepwDialog extends Dialog implements ActionListener{
	 JPanel jpanel,jpanel1,jpanel2,jpanel3,jpaneln;
	 JTextField tfP,tfPre;
	 JLabel lbPw,lbPwre;
	 Font font;
	 JButton jbtnOk,jbtnCancel;
	 UiFindIdPw fip;
	 private ArrayList<UiJoindata>list=new ArrayList<UiJoindata>();
	 private final String PATH = "../oxoxProj/src/oxox.txt";
  @Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==jbtnOk) {
			if(tfP.getText().trim().equals(tfPre.getText().trim())) {
				try {
					openMember();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println(fip.intindex);
				list.get(fip.intindex).setPw(tfP.getText());
				list.get(fip.intindex).setRepw(tfP.getText());
				
				saveMember();
				System.out.println(list);
				this.dispose();
			}else {
				JOptionPane.showMessageDialog(null,"�� ��й�ȣ�� �ٸ��ϴ�.","��й�ȣ ã��",JOptionPane.WARNING_MESSAGE);
			}
		}
		if(e.getSource()==jbtnCancel){
			this.dispose();
		}
		
  }
  public void openMember() throws Exception {
		
		ObjectInputStream ois=null;
		try {
			ois=new ObjectInputStream(new FileInputStream(PATH));
			list=(ArrayList<UiJoindata>) ois.readObject();
		} catch (Exception e) {
			// TODO: handle exception
			list=new ArrayList<UiJoindata>();
			try {
				new File(PATH).createNewFile();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally {
			if(ois!=null)ois.close();
		}
	} 
	public void saveMember() {
		ObjectOutputStream oos=null;
		
		try {
			oos=new ObjectOutputStream(new FileOutputStream(PATH));
			oos.writeObject(list);
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			if(oos!=null)
				try {
					oos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
  public void initpro() {
	  font=new Font("����", Font.BOLD, 15);
	  jpanel=new JPanel();
	  jpanel1=new JPanel();
	  jpanel2=new JPanel();
	  jpanel3=new JPanel();
	  jpaneln=new JPanel();
	  
	  tfP=new JTextField(20);
	  tfPre=new JTextField(20);
	  
	  jbtnOk=new JButton("Ȯ  ��");
	  jbtnOk.addActionListener(this);
	  
	  
	  jbtnCancel=new JButton("�� ��");
	  jbtnCancel.addActionListener(this);
	  
	  lbPw=new JLabel("����й�ȣ");
	  lbPw.setFont(font);
	  lbPwre=new JLabel("��   Ȯ   ��");
	  lbPwre.setFont(font);
	  this.add(jpanel);
	  jpanel.add(jpaneln);
	  jpanel.setLayout(new GridLayout(4, 1));
	  jpanel.add(jpanel1);
	  jpanel1.setLayout(new FlowLayout(FlowLayout.LEFT,30,0));
	  jpanel.add(jpanel2);
	  jpanel2.setLayout(new FlowLayout(FlowLayout.LEFT,28,0));
	  jpanel.add(jpanel3);
	  jpanel3.setLayout(new FlowLayout(FlowLayout.CENTER,30,0));
	  jpanel1.add(lbPw);
	  jpanel1.add(tfP);
	  jpanel2.add(lbPwre);
	  jpanel2.add(tfPre);
	  jpanel3.add(jbtnOk);
	  jpanel3.add(jbtnCancel);
	  
	  
	  
  }
	public ChangepwDialog(UiFindIdPw uifindidpw) {
	  super(uifindidpw);
	  fip = uifindidpw;
	  initpro();
	  this.setVisible(true);
	  this.setTitle("PW �����ϱ�");
      this.setBounds(100, 100, 400, 400);
	  
	  this.addWindowListener(new WindowAdapter() {

		@Override
		public void windowClosing(WindowEvent e) {
			// TODO Auto-generated method stub
			//System.exit(0);
			//uifindidpw.strPass = returnpw;
			ChangepwDialog.this.dispose();
		}
	});
  }
}
