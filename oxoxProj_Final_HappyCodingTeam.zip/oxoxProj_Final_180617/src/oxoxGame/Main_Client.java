package oxoxGame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Main_Client extends JFrame implements ActionListener, MouseListener {

	// ui
	private Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	private JPanel jpnMain, jpnMainImage, jpnMainUi;
	private JButton jbtnJoin, jbtnLogin, jbtnFind;
	
	private Color cMain = new Color(255, 228, 0);
	private Color cGame = new Color(255, 255, 0);
	
	private JLabel jlbMainImage, jlbJoin, jlbFind;
	private ImageIcon mainImage = new ImageIcon(this.getClass().getResource("").getPath() + "../image/loginMain.jpg");
	private JTextField jtfId, jtfPw;
	private int indexId = -1, indexPw = -2;
	private final String PATH = this.getClass().getResource("").getPath() + "/oxox.txt";
	private ArrayList<UiJoindata> memberList = new ArrayList<UiJoindata>();

	private Thread_Chat thread_Chat;
	private Ui_WaitRoom ui_WaitRoom;
	private UiFindIdPw uiFindIdPw;
	private UiJoin uijoin;
	private String strId, strNick;
	private UserInfo userInfo = new UserInfo();

	// ����
	private static final int PORT = 5000;
	private Socket socket;
	private ObjectOutputStream oos = null;
	private ObjectInputStream ois = null;

	// protocol
	final static public int CHAT = 0;
	final static public int LOGIN = 1;
	final static public int MOVE = 2;
	final static public int START = 3;
	final static public int EXIT = 4;
	final static public int WHISPER = 5;
	final static public int GAMEROOM = 6;

	
	
	public UserInfo getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	public Thread_Chat getThread_Chat() {
		return thread_Chat;
	}

	public void setThread_Chat(Thread_Chat thread_Chat) {
		this.thread_Chat = thread_Chat;
	}

	public Ui_WaitRoom getUi_WaitRoom() {
		return ui_WaitRoom;
	}

	public void setUi_WaitRoom(Ui_WaitRoom ui_WaitRoom) {
		this.ui_WaitRoom = ui_WaitRoom;
	}

	public ObjectInputStream getOis() {
		return ois;
	}

	public void setOis(ObjectInputStream ois) {
		this.ois = ois;
	}

	public ObjectOutputStream getOos() {
		return oos;
	}

	public void setOos(ObjectOutputStream oos) {
		this.oos = oos;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	public String getPATH() {
		return PATH;
	}

	public String getStrId() {
		return strId;
	}

	public void setStrId(String strId) {
		this.strId = strId;
	}

	public String getStrNick() {
		return strNick;
	}

	public void setStrNick(String strNick) {
		this.strNick = strNick;
	}

	public void connect() {// ����
		try {
			socket = new Socket("127.0.0.1", PORT);

			oos = new ObjectOutputStream(socket.getOutputStream());
			ois = new ObjectInputStream(socket.getInputStream());
			strId = jtfId.getText();
			strNick = memberList.get(indexId).getNickname();
			ui_WaitRoom = new Ui_WaitRoom(this);
			thread_Chat = new Thread_Chat(this, ui_WaitRoom);
			send();
			System.out.println(userInfo);
			thread_Chat.start();
			System.out.println("����Ǿ����ϴ�.");
			this.dispose();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//System.out.println("connection error");
		}
	}

	public void send() {// �α��� - id/�г��� ������
		UserInfo userInfo = new UserInfo();
		userInfo.nRoom = 0;
		userInfo.strRoomName ="����";
		userInfo.strID = jtfId.getText();
		userInfo.strNick = memberList.get(indexId).getNickname();
		this.userInfo.nRoom = 0;
		this.userInfo.strRoomName ="����";
		this.userInfo.strID = jtfId.getText();
		this.userInfo.strNick = memberList.get(indexId).getNickname();
		try {
			oos.writeObject(userInfo);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void memberShow() {
		try {
			openMember();
			System.out.println("�������");
			System.out.println(PATH);
			System.out.println(memberList.size());
			for (int i = 0; i < memberList.size(); i++) {
				System.out.println(memberList.get(i));
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}	
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == jlbJoin) {// ȸ������
			uijoin = new UiJoin(this);

		}
		if (e.getSource() == jlbFind) {
			System.out.println("���̵� ��й�ȣã��");
			uiFindIdPw = new UiFindIdPw();
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		// System.out.println(e.getSource());
		if (e.getSource() == jlbJoin) {
			jlbJoin.setFont(new Font("����", Font.BOLD, 15));
		}
		if (e.getSource() == jlbFind) {
			jlbFind.setFont(new Font("����", Font.BOLD, 15));
		}
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == jlbJoin) {
			jlbJoin.setFont(new Font("����", Font.PLAIN, 13));
		}
		if (e.getSource() == jlbFind) {
			jlbFind.setFont(new Font("����", Font.PLAIN, 13));
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == jbtnJoin) {// ȸ������
			uijoin = new UiJoin(this);

		}
		if (e.getSource() == jbtnLogin) {

			try {
				openMember();

				for (int i = 0; i < memberList.size(); i++) {
					System.out.println(memberList.get(i));
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			logininfo();
			if (jtfId.getText().equals("admin") && jtfPw.getText().equals("admin")) {
				AdminMember ma = new AdminMember();
			} else {

				if (indexId == indexPw) {
					connect();
				} else {
					JOptionPane.showMessageDialog(null, "���̵� �Ǵ� ��й�ȣ�� �߸�����ϴ�.", "�α���", JOptionPane.WARNING_MESSAGE);
				}
			}
		}
		if (e.getSource() == jbtnFind) {
			System.out.println("���̵� ��й�ȣã��");
			uiFindIdPw = new UiFindIdPw();
		}

	}
	public void logininfo() {
		try {
			openMember();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		indexId = -1;
		indexPw = -2;
		for (int i = 0; i < memberList.size(); i++) {
			if (memberList.get(i).getId().equals(jtfId.getText().trim())) {
				indexId = i;
			}
		}
		for (int i = 0; i < memberList.size(); i++) {
			if (memberList.get(indexId).getPw().equals(jtfPw.getText().trim())) {
				indexPw = indexId;
			}
		}
	}

	public void openMember() throws Exception {

		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(new FileInputStream(PATH));
			memberList = (ArrayList<UiJoindata>) ois.readObject();
		} catch (Exception e) {
			// TODO: handle exception
			memberList = new ArrayList<UiJoindata>();
			try {
				new FileOutputStream(new File(PATH));
			} catch (Exception e1) {
				// TODO Auto-generated catch block

				e1.printStackTrace();
			}
		} finally {
			if (ois != null)
				ois.close();
		}
	}
	


	public void initPro() {

		jpnMain = new JPanel();
		jlbMainImage = new JLabel(mainImage);
		jlbJoin = new JLabel("ȸ������");
		jlbJoin.addMouseListener(this);
		jbtnLogin = new JButton("�α���");
		jbtnLogin.setBackground(cGame);
		jbtnLogin.addActionListener(this);
		jlbFind = new JLabel("���̵� ��й�ȣã��");
		jlbFind.addMouseListener(this);
		jtfId = new JTextField(30);
		jtfPw = new JPasswordField(30);
		jtfId.setBounds(450, 300, 270, 40);
		jtfPw.setBounds(450, 350, 270, 40);
		jbtnLogin.setBounds(750, 300, 90, 90);
		jlbJoin.setBounds(450, 400, 90, 30);
		jlbJoin.setFont(new Font("����", Font.PLAIN, 13));
		jlbFind.setBounds(550, 400, 160, 30);
		jlbFind.setFont(new Font("����", Font.PLAIN, 13));

		jlbMainImage.add(jtfId);
		jlbMainImage.add(jtfPw);
		jlbMainImage.add(jlbJoin);
		jlbMainImage.add(jlbFind);
		jlbMainImage.add(jbtnLogin);
		jpnMain.add(jlbMainImage);
		this.add(jpnMain);

	}

	public Main_Client() {
		this.setTitle("OX Quiz");
		try {
			openMember();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		initPro();
		this.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
			}

		});
		this.setBounds(100, 100, 1300, 900);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		new Main_Client();

	}

}
