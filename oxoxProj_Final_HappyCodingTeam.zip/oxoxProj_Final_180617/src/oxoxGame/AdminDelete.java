package oxoxGame;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AdminDelete extends JFrame implements ActionListener{
	private final String PATH = "../oxoxProj/src/oxox.txt";
	private ArrayList<UiJoindata>list=new ArrayList<UiJoindata>();
	JPanel jpanel1,jpanel2,jpanel3,jpanel,jpanel4,jpanel5;
	JTextField jtf;
	JButton jbtn1,jbtn2;
	JLabel jl1;
	Font font;
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource().equals(jbtn1)) {
			deletelist();
			saveMember();
			JOptionPane.showMessageDialog(null,"�����Ǿ����ϴ�","admin",JOptionPane.PLAIN_MESSAGE);
			this.dispose();
			AdminMember m1=new AdminMember();
		}
		if(e.getSource().equals(jbtn1)) {
			this.dispose();
		}
	}
	public void initPro() {
		font=new Font("����", Font.BOLD, 15);
		
		jpanel=new JPanel();
		jpanel.setLayout(new BoxLayout(jpanel,BoxLayout.Y_AXIS));
		this.add(jpanel);
		jpanel1=new JPanel(new FlowLayout(FlowLayout.CENTER));
		jpanel2=new JPanel(new FlowLayout(FlowLayout.CENTER));
		jpanel3=new JPanel(new FlowLayout(FlowLayout.CENTER));
		jpanel4=new JPanel(new FlowLayout(FlowLayout.CENTER));
		jpanel5=new JPanel(new FlowLayout(FlowLayout.CENTER));
		
		jpanel.add(jpanel4);
		jpanel.add(jpanel1);
		jpanel.add(jpanel2);
		jpanel.add(jpanel3);
		jpanel.add(jpanel5);
		
		jtf=new JTextField(15);
		
		jl1=new JLabel("�����Ͻ� ���̵� �Է����ּ���");
		jl1.setFont(font);
		
		jbtn1=new JButton("Ȯ��");
		jbtn1.addActionListener(this);
		jbtn2=new JButton("���");
		jbtn2.addActionListener(this);
		jpanel1.add(jl1);
		
		jpanel2.add(jtf);
		
		jpanel3.add(jbtn1);
		jpanel3.add(jbtn2);
	}
	public void deletelist() {
		for(int i=0;i<list.size();i++) {
			if(list.get(i).getId().equals(jtf.getText())) {
				list.remove(i);
				System.out.println("��������");
				return;
			}
		}
			
	}
	public void saveMember() {
		ObjectOutputStream oos=null;
		
		try {
			oos=new ObjectOutputStream(new FileOutputStream(PATH));
			oos.writeObject(list);
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			if(oos!=null)
				try {
					oos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	public void openMember() throws Exception {
		
		ObjectInputStream ois=null;
		try {
			ois=new ObjectInputStream(new FileInputStream(PATH));
			list=(ArrayList<UiJoindata>) ois.readObject();
		} catch (Exception e) {
			// TODO: handle exception
			list=new ArrayList<UiJoindata>();
			try {
				new File(PATH).createNewFile();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally {
			if(ois!=null)ois.close();
		}
	} 
	public AdminDelete() {
		  try {
			openMember();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		  setTitle("����");
	      initPro();
	      this.addWindowListener(new WindowAdapter() {

	         @Override
	         public void windowClosing(WindowEvent e) {
	            // TODO Auto-generated method stub
	            dispose();
	         }

	      });
	      this.pack();
	      this.setBounds(100, 100,300, 200);
	      this.setVisible(true);
	   }
	public static void main(String[] args) {
		new AdminDelete();
	}
}
