package oxoxGame;

import java.net.Socket;

import javax.swing.JLabel;

public class Thread_Move extends Thread {
	private Ui_GameRoom ui_GameRoom;
	private JLabel lbPlayer;
	private UserInfo userInfo;
	private PlayerMove playerMove = new PlayerMove();

	private boolean isStop;
	private int x, y;
	private int nCharSpeed = 5;// �������� ������
	private int nIndex;
	
	public int getnIndex() {
		return nIndex;
	}

	public PlayerMove getPlayerMove() {
		return playerMove;
	}

	public void setPlayerMove(PlayerMove playerMove) {
		this.playerMove = playerMove;
	}

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	public boolean isStop() {
		isStop = true;
		return isStop;
	}

	public void moveX() {

		if (x > playerMove.chX) {
			x = x - 1;
		} else if (x < playerMove.chX) {
			x = x + 1;
		}
	}

	// oxox Ŭ�������� thread class�� ������ �� ���ڰ��� �Ѱ� �޾� �ʱ�ȭ �ϴ� ������ �̴�.
	public void moveY() {
		if (y > playerMove.chY) {
			y = y - 1;
		} else if (y < playerMove.chY) {
			y = y + 1;
		}
	}
	public Thread_Move(Ui_GameRoom ui_GameRoom, JLabel lbPlayer) {
		this.ui_GameRoom = ui_GameRoom;
		this.x = ui_GameRoom.getChX();
		this.y = ui_GameRoom.getChY();
		this.lbPlayer = lbPlayer;
		this.userInfo = ui_GameRoom.getUserInfo();
		
	}
	
	public Thread_Move(Ui_GameRoom ui_GameRoom, PlayerMove pmove, JLabel lbPlayer) {
		this.ui_GameRoom = ui_GameRoom;
		this.x = ui_GameRoom.getChX();
		this.y = ui_GameRoom.getChY();
		this.lbPlayer = lbPlayer;
		this.userInfo = ui_GameRoom.getUserInfo();
		this.playerMove = pmove;
	}

	@Override
	public void run() {

		while (!isStop) {
			while (!isStop) {
				while (!isStop) {
					if (!(ui_GameRoom.getPlayerList().get(playerMove.nPosition).nIndex == 0)) {
						nIndex = ui_GameRoom.getPlayerList().get(playerMove.nPosition).nIndex;
						moveX();
						moveY();
						if ((ui_GameRoom.getPlayerList().get(playerMove.nPosition).chX == x)&&
								(ui_GameRoom.getPlayerList().get(playerMove.nPosition).chY == y)) {
							ui_GameRoom.getPlayerList().get(playerMove.nPosition).nIndex = 0;
							break;
						}
					}
					lbPlayer.setBounds(x, y, lbPlayer.getWidth(), lbPlayer.getHeight());
					try {
						this.sleep(nCharSpeed);// �̵��ӵ� ����
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}
		}
	}

}