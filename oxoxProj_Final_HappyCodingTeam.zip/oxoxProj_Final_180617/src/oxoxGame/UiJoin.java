package oxoxGame;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import java.awt.Font;

public class UiJoin extends Frame implements ActionListener {
	private JPanel jpnMain, jpnTitle, jpnName, jpnID, jpnPW1, jpnPW2, jpnPhone, jpnNick, jpnAddbtn;
	private JButton jbtnCheck, jbtnOk, jbtnCancel;
	private JTextField tfName, tfId, tfPw1, tfPw2, tfPhone, tfNick;
	private JLabel lbTitle, lbName, lbID, lbPW, lbRePw, lbPhone, lbNick;
	private Font fontT, fontN;
	private String testid = null;
	private int k = 0;

	private ArrayList<UiJoindata> list = new ArrayList<UiJoindata>();

	private UiJoindata uiJoindata;
	private static Main_Client uiLoginMain;

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == jbtnCheck) {
			try {
				openMember();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			idDoubleCheck();
			if (k == -1) {
				JOptionPane.showMessageDialog(null, "���̵� �ߺ��Ǿ����ϴ�.", "���̵� �ߺ� üũ", JOptionPane.WARNING_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(null, "��밡���� ���̵��Դϴ�.", "���̵� �ߺ� üũ", JOptionPane.PLAIN_MESSAGE);
			}
		}
		if (e.getSource() == jbtnOk) {
			if (tfPw1.getText().trim().equals(tfPw2.getText().trim())) {

				try {
					openMember();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				joinMember();
				saveMember();
				this.dispose();

			} else {
				JOptionPane.showMessageDialog(null, "�κ�й�ȣ�� ��ġ���� �ʽ��ϴ�", "ȸ������", JOptionPane.WARNING_MESSAGE);

			}
		}
		if (e.getSource() == jbtnCancel) {
			this.dispose();
		}
	}

	public int idDoubleCheck() {
		testid = tfPw2.getText().trim();

		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getId().trim().equals(tfId.getText().trim())) {
				return k = -1;
			}
		}
		return k = 0;
	}

	public void joinMember() {
		uiJoindata = new UiJoindata();
		uiJoindata.setName(tfName.getText().trim());
		uiJoindata.setNickname(tfNick.getText().trim());
		uiJoindata.setId(tfId.getText().trim());
		uiJoindata.setPw(tfPw1.getText().trim());
		uiJoindata.setRepw(tfPw2.getText().trim());
		uiJoindata.setPhone(tfPhone.getText().trim());

		list.add(uiJoindata);
//		System.out.println(list);

	}

	public void saveMember() {
		ObjectOutputStream oos = null;

		try {
			oos = new ObjectOutputStream(new FileOutputStream(uiLoginMain.getPATH()));
			oos.writeObject(list);
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			if (oos != null)
				try {
					oos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

	public void openMember() throws Exception {

		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(new FileInputStream(uiLoginMain.getPATH()));
			list = (ArrayList<UiJoindata>) ois.readObject();
		} catch (Exception e) {
			// TODO: handle exception
			list = new ArrayList<UiJoindata>();
			try {
				new File(uiLoginMain.getPATH()).createNewFile();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			if (ois != null)
				ois.close();
		}
	}

	public void initPro() {
		jpnMain = new JPanel();
		jpnMain.setLayout(new BoxLayout(jpnMain, BoxLayout.Y_AXIS));
		jpnTitle = new JPanel();
		jpnTitle.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 20));
		jpnName = new JPanel();
		jpnName.setLayout(new FlowLayout(FlowLayout.LEFT, 30, 0));
		jpnID = new JPanel();
		jpnID.setLayout(new FlowLayout(FlowLayout.LEFT, 30, 0));
		jpnPW1 = new JPanel();
		jpnPW1.setLayout(new FlowLayout(FlowLayout.LEFT, 30, 0));
		jpnPW2 = new JPanel();
		jpnPW2.setLayout(new FlowLayout(FlowLayout.LEFT, 27, 0));
		jpnPhone = new JPanel();
		jpnPhone.setLayout(new FlowLayout(FlowLayout.LEFT, 25, 0));
		jpnNick = new JPanel();
		jpnNick.setLayout(new FlowLayout(FlowLayout.LEFT, 27, 0));
		jpnAddbtn = new JPanel();
		jpnAddbtn.setLayout(new FlowLayout(FlowLayout.CENTER, 40, 0));
		jbtnCheck = new JButton();
		jbtnOk = new JButton();
		jbtnCancel = new JButton();
		tfName = new JTextField(20);
		tfId = new JTextField(20);
		tfPw1 = new JPasswordField(20);
		tfPw2 = new JPasswordField(20);
		tfPhone = new JTextField(20);
		tfNick = new JTextField(20);
		lbTitle = new JLabel("ȸ������");
		fontT = new Font("����", Font.BOLD, 25);
		lbName = new JLabel("Name");
		fontN = new Font("����", Font.BOLD, 15);
		lbID = new JLabel("   ID ");
		lbPW = new JLabel("  PW");
		lbRePw = new JLabel("���Է�");
		lbPhone = new JLabel("Phone");
		lbNick = new JLabel("�г���");

		jpnInfo();
		titleInfo();
		nameInfo();
		idInfo();
		pw1Info();
		pw2Info();
		phoneInfo();
		btnInfo();
		nickInfo();

		this.add(jpnMain);

	}

	public void jpnInfo() {
		jpnMain.add(jpnTitle);
		jpnMain.add(jpnName);
		jpnMain.add(jpnNick);
		jpnMain.add(jpnID);
		jpnMain.add(jpnPW1);
		jpnMain.add(jpnPW2);
		jpnMain.add(jpnPhone);
		jpnMain.add(jpnAddbtn);

	}

	public void titleInfo() {
		lbTitle.setFont(fontT);
		lbTitle.setForeground(Color.black);
		jpnTitle.add(lbTitle);
	}

	public void nameInfo() {
		lbName.setFont(fontN);
		jpnName.add(lbName);
		jpnName.add(tfName);
	}

	public void nickInfo() {
		lbNick.setFont(fontN);
		jpnNick.add(lbNick);
		jpnNick.add(tfNick);
	}

	public void idInfo() {
		lbID.setFont(fontN);
		jpnID.add(lbID);
		jpnID.add(tfId);
		jbtnCheck.setText("�ߺ�Ȯ��");
		jbtnCheck.addActionListener(this);
		jpnID.add(jbtnCheck);
	}

	public void pw1Info() {
		lbPW.setFont(fontN);
		jpnPW1.add(lbPW);
		jpnPW1.add(tfPw1);
	}

	public void pw2Info() {
		lbRePw.setFont(fontN);
		jpnPW2.add(lbRePw);
		jpnPW2.add(tfPw2);
	}

	public void phoneInfo() {
		lbPhone.setFont(fontN);
		jpnPhone.add(lbPhone);
		jpnPhone.add(tfPhone);
	}

	public void btnInfo() {
		jbtnOk.setText("Ȯ  ��");
		jbtnOk.addActionListener(this);
		jbtnCancel.setText("��  ��");
		jbtnCancel.addActionListener(this);
		jpnAddbtn.add(jbtnOk);
		jpnAddbtn.add(jbtnCancel);
	}

	public UiJoin() {
		setTitle("ȸ������");
		initPro();
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
		this.pack();
		this.setBounds(100, 100, 500, 500);
		this.setVisible(true);
	}

	public UiJoin(Main_Client uiLoginMain) {
		this.uiLoginMain = uiLoginMain;
		new UiJoin();
	}

}