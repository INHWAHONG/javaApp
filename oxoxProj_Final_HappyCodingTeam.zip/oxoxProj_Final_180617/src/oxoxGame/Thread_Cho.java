package oxoxGame;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Arrays;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class Thread_Cho extends Thread {
	OxoxZocbo oxoxzocbo;
	Ui_GameRoom ui_GameRoom;
	int nCount;
	int[] nQuiz = new int[10];
	boolean bStart = false;
	boolean bMent = false;
	boolean bGameStart = false;

	boolean isStop = false;

	public boolean isStop() {
		isStop = true;
		return isStop;
	}

	@Override
	public String toString() {
		return "Thread_Cho [nQuiz=" + Arrays.toString(nQuiz) + "]";
	}

	public void setStop(boolean isStop) {
		this.isStop = isStop;
	}

	public Thread_Cho(Ui_GameRoom ui_GameRoom) {
		super();
		this.ui_GameRoom = ui_GameRoom;
	}

	@Override
	public void run() {
		oxoxzocbo = new OxoxZocbo();
		int number = 0;

		int nTimeControl = 1000; // ���Ӵ��ð����� 100 = 1��
		int nGameControl = 1000;
		double fWait = nTimeControl / 100;
		double fGame = nGameControl / 100;
		while (!isStop) {
			// System.out.println("ī��Ʈ�ٿ�running");
			// TODO Auto-generated method stub
			try {
				Thread.sleep(10); // 1000 1sec 10 0.01ms
				nCount++;

				// boolean bStart = false; //���� �ʹ� �ʽð� ����
				// boolean bMent = false; //���� ��Ʈ ����
				// boolean bGameStart = false; //���� ���� ����
				// ui_GameRoom.getRoomInfo().bPaly //���ӹ� ������ ����

				// 2��° ����...
				if ((bGameStart == false) && (bMent == false) && ui_GameRoom.getRoomInfo().bPaly) {
					bGameStart = true;
					bMent = true;
					nCount = 0;
				}
				// �ʽð� 00.00 ���·� ���.
				if ((!ui_GameRoom.getRoomInfo().bPaly) && (bGameStart == false)) {
					if (nCount < nTimeControl) {
						if (nCount % 1 == 0) {
							DecimalFormat df = new DecimalFormat("00.00");
							String str = df.format(fWait - ((double) nCount) / 100);
							ui_GameRoom.getLbcho().setText(str);
						}
					}
				}
				// 1��° ����...
				if (nCount == nTimeControl && (ui_GameRoom.getRoomInfo().bPaly == false)) { // ���۽�ȣ ����
					RoomInfo roomInfo = ui_GameRoom.getRoomInfo();
					try {
						roomInfo.bPaly = true;
						ui_GameRoom.getMain_Client().getOos().writeObject(roomInfo);

						ui_GameRoom.getLbcho().setText("00.00");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				if (bMent && bGameStart && ui_GameRoom.getRoomInfo().bPaly) {
					if (nCount == 100) {
						//nQuiz = ui_GameRoom.getRoomInfo().nQuiz;// ���� ������Ʈ...
						ui_GameRoom.getLbcho().setText("00.00");
						ui_GameRoom.getJtaQuest().setText("�̰��� ���� ������ ȯ���մϴ�.");
					}
					if (nCount == 300) {
						ui_GameRoom.getJtaQuest().setText("�� ������ �ູ�ڵ����� OX�����Դϴ�.");
					}
					if (nCount == 500) {
						ui_GameRoom.getJtaQuest().setText("F1, �� Ű�� ������ O,\r\n");
						ui_GameRoom.getJtaQuest().append("F2, �� Ű�� ������ X�� �̵��մϴ�.");
					}
					if (nCount == 700) {
						ui_GameRoom.getJtaQuest().setText("������ �� 10�����Դϴ�.\r\n");
						ui_GameRoom.getJtaQuest().append("Ʋ���� �������� �̵��մϴ�.");
					}

					if (nCount == 900) {
						ui_GameRoom.getJtaQuest().setText("�����մϴ�.");

					}
					if (nCount == 1000) {
						bMent = false;
						bStart = true;
						nCount = 0;
					}
				}

				if (bStart && bGameStart && ui_GameRoom.getRoomInfo().bPaly) {

					if (number == 10) {
						new Thread() {
							public void run() {
								int nRefresh = 0;
								boolean bRefresh = true;
								while (bRefresh) {
									try {
										Thread.sleep(10);
										nRefresh++;
									} catch (InterruptedException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
									if (nRefresh == 300) {
										isStop();
										ui_GameRoom.quit();
										bRefresh = false;
									}
								}
							}
						}.start();
						JOptionPane.showMessageDialog(null, "����� ���� õ��!", "�¸�", JOptionPane.PLAIN_MESSAGE);
						ui_GameRoom.quit();
						isStop();
						return;
					}

					if (nCount < nGameControl) {
						if (nCount % 1 == 0) {
							DecimalFormat df = new DecimalFormat("00.00");
							String str = df.format(fGame - ((double) nCount) / 100);
							ui_GameRoom.getLbcho().setText(str);
						}
					}
					// ����
					if (nCount == 10) {
						ui_GameRoom.getJtaQuest()
								.setText((number + 1 + "������. " + oxoxzocbo.getJockbo()[nQuiz[number]][1]));

					}
					// ����Ȯ��
					if (nCount == nGameControl) {
						ui_GameRoom.centerMove(oxoxzocbo.getJockbo()[nQuiz[number]][0]);
						ui_GameRoom.getLbcho().setText("00.00");
						// System.out.println("1:" + oxoxzocbo.getJockbo()[nQuiz[number]][1]);
						// System.out.println("1:" + oxoxzocbo.getJockbo()[nQuiz[number]][0]);
						// System.out.println("����:" + oxoxGameRoom.getChoice());
						ui_GameRoom.getJtaQuest()
								.setText((number + 1 + "�� ���� ������" + oxoxzocbo.getJockbo()[nQuiz[number]][0]));
						if (oxoxzocbo.getJockbo()[nQuiz[number]][0].equals(ui_GameRoom.getPlayerMove().strAnswer)) {

							new Thread() {

								int nRefresh = 0;
								boolean bRefresh = true;

								public void run() {
									while (bRefresh) {
										new Thread() {
											public void run() {
												int nRefresh = 0;
												boolean bRefresh = true;
												while (bRefresh) {
													try {
														Thread.sleep(10);
														nRefresh++;
													} catch (InterruptedException e) {
														// TODO Auto-generated catch block
														e.printStackTrace();
													}
													if (nRefresh == 300) {
														JOptionPane.getRootFrame().dispose();
														bRefresh = false;
													}
												}
											}
										}.start();
										JOptionPane.showMessageDialog(null, "�����Դϴ�.");
										bRefresh = false;
									}
								}
							}.start();
						} else {
							new Thread() {
								int nRefresh = 0;
								boolean bRefresh = true;

								public void run() {
									while (bRefresh) {
										new Thread() {
											public void run() {
												int nRefresh = 0;
												boolean bRefresh = true;
												while (bRefresh) {
													try {
														Thread.sleep(10);
														nRefresh++;
													} catch (InterruptedException e) {
														// TODO Auto-generated catch block
														e.printStackTrace();
													}
													if (nRefresh == 300) {
														JOptionPane.getRootFrame().dispose();
														bRefresh = false;
													}
												}
											}
										}.start();
										JOptionPane.showMessageDialog(null, "�����Դϴ�.3�� �� �ڵ����� ���Ƿΰ����ϴ�.");
										isStop();
										ui_GameRoom.quit();
										return;
									}
								}
							}.start();
						}
					}
					// �ʱ�ȭ
					if (nCount == 300 + nGameControl) {
						nCount = 0;
						number++;

					}
				}

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

}