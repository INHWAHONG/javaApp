package oxoxGame;



import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class AdminMember extends Frame implements ActionListener{

	private JScrollPane jsp;		//��ũ�ѻ���
	int ROW,COl;					// ��,�� ���� �ε��� ����
	JPanel jpanel;
	JButton jbtn1,jbtn2,jbtn3;
	 private final String PATH = "../oxoxProj/src/oxox.txt";
	   private ArrayList<UiJoindata>list=new ArrayList<UiJoindata>();
	   JtableModel jm=new JtableModel();
	UiJoin uj;
	
	//private String []columName= {"Name", "ID","PW","Phone","Address"};
	
	public void initpro() {
		jpanel=new JPanel();
		jbtn1=new JButton("�߰�");
		jbtn1.addActionListener(this);
		jbtn2=new JButton("����");
		jbtn2.addActionListener(this);
		jbtn3=new JButton("����");
		jbtn3.addActionListener(this);
		this.add(jpanel);
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource().equals(jbtn1)) {
			AdminAdd ad=new AdminAdd();
			this.dispose();
		}
		if(e.getSource().equals(jbtn2)) {
			System.out.println("����");
			AdminModify am=new AdminModify();
			this.dispose();
		}
		if(e.getSource().equals(jbtn3)) {
			System.out.println("����");
			AdminDelete de=new AdminDelete();
			this.dispose();
		}
	}
	public void jtableObj() {
		
		Object[][] data=new Object[list.size()][5];
		
		
		for (int i = 0; i < list.size(); i++) {
			for (int j = 0; j < 5; j++) {
				 
			   	 data[i][j++]=list.get(i).getName();
			   	 data[i][j++]=list.get(i).getNickname();
				 data[i][j++]=list.get(i).getId();
				 data[i][j++]=list.get(i).getPw();
				 data[i][j++]=list.get(i).getPhone();
						 
				}
			}
		
	
		jm.setData(data);
	}
	public void jtableTest() {
		try {
			openMember();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jtableObj();
		jsp=new JScrollPane(new JTable(jm),
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		initpro();
		jpanel.add(jsp);
		jpanel.add(jbtn1);
		jpanel.add(jbtn2);
		jpanel.add(jbtn3);
		
	}
	
	public void saveMember() {
		ObjectOutputStream oos=null;
		
		try {
			oos=new ObjectOutputStream(new FileOutputStream(PATH));
			oos.writeObject(list);
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			if(oos!=null)
				try {
					oos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	public void openMember() throws Exception {
		
		ObjectInputStream ois=null;
		try {
			ois=new ObjectInputStream(new FileInputStream(PATH));
			list=(ArrayList<UiJoindata>) ois.readObject();
		} catch (Exception e) {
			// TODO: handle exception
			list=new ArrayList<UiJoindata>();
			try {
				new File(PATH).createNewFile();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally {
			if(ois!=null)ois.close();
		}
	}
	
	public AdminMember() {
		jtableTest();
		this.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
			}

		});
		this.setTitle("ȸ�����");
		this.setBounds(100, 100, 500, 550);
		this.setVisible(true);
		
	}

	public static void main(String[] args) {
		new AdminMember();
	}

}
