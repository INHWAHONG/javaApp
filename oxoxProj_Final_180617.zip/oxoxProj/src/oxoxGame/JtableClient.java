package oxoxGame;

import javax.swing.table.AbstractTableModel;

public class JtableClient extends AbstractTableModel {
	
	 private Object[][]data= {null};
	 	 


	private String []columName= {"NO","�г���", "ID"};
	 public Object[][] getData() {
		return data;
	}
	public void setData(Object[][] data) {
		this.data = data;
	}

	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		data[rowIndex][columnIndex]=aValue;
	}

	@Override
	public String getColumnName(int column) {
		// TODO Auto-generated method stub
		return columName[column];
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return columnIndex == 0?true:false;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return data.length;
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return columName.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return data[rowIndex][columnIndex];
	}
	
	
}