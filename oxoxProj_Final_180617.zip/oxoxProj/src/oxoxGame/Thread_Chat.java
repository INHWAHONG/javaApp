package oxoxGame;

import java.awt.Color;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

public class Thread_Chat extends Thread {

	private Color cMain = new Color(255, 228, 0);
	private Color cGame = new Color(255, 255, 0);

	private Ui_WaitRoom ui_WaitRoom;
	private Main_Client main_Client;
	private Ui_GameRoom ui_GameRoom;
	private Socket socket;

	final static public int CHAT = 0;
	final static public int LOGIN = 1;
	final static public int MOVE = 2;
	final static public int START = 3;
	final static public int EXIT = 4;
	final static public int USERLIST = 5;
	final static public int GAMEROOM = 6;

	public void setUi_GameRoom(Ui_GameRoom ui_GameRoom) {
		this.ui_GameRoom = ui_GameRoom;
	}

	public Thread_Chat(Main_Client main_Client, Ui_WaitRoom ui_WaitRoom) {// ������
		super();
		this.main_Client = main_Client;
		this.ui_WaitRoom = ui_WaitRoom;
	}

	public void resetTable(ArrayList<UserInfo> userInfo) {// ���̺� ������Ʈ�� ������ ������
		// System.out.println("table���� ����Դϴ�.");
		// System.out.println("�������� �������� " + userInfo.size() + "�� �Դϴ�.");
		// System.out.println("��ѹ��� "+userInfo.get(0).strRoom);
		String[][] strArrTemp = new String[userInfo.size()][];// user����ŭ �迭�������

		for (int i = 0; i < strArrTemp.length; i++) {
			String[] strUser = new String[4];
			strUser[0] = String.valueOf(userInfo.get(i).nRoom);
			strUser[1] = userInfo.get(i).strID;
			strUser[2] = userInfo.get(i).strNick;
			strUser[3] = userInfo.get(i).strRoomName;
			strArrTemp[i] = strUser;
			// System.out.println(i+"_"+userInfo.get(i));
		}
		ui_WaitRoom.jtableUpdate(strArrTemp);

	}

	public void resetRoom(ArrayList<RoomInfo> roomInfo) {

		ArrayList<RoomInfo> resetRoom = roomInfo;

		for (int i = 1; i < resetRoom.size(); i++) {
			if (!resetRoom.get(i).bPaly) {
				ui_WaitRoom.getBtnList().get(i - 1).setEnabled(true);
				ui_WaitRoom.getBtnList().get(i - 1).setBackground(cMain);
			} else {
				ui_WaitRoom.getBtnList().get(i - 1).setEnabled(false);
				ui_WaitRoom.getBtnList().get(i - 1).setBackground(cMain);
			}
			ui_WaitRoom.getBtnList().get(i - 1).setText(resetRoom.get(i).strRoomName);
		}
	}

	public void moveCheck(PlayerMove playerMove) {
		// System.out.println(playerMove);
		for (int i = 0; i < ui_GameRoom.getThread_MoveList().size(); i++) {// ������� �濡�ִ� ������ ���ȣ �� �� ��ġ�ϸ� ���ӽ��� �޼��� ����
			if (playerMove.userInfo.nRoom == ui_GameRoom.getThread_MoveList().get(i).getUserInfo().nRoom) {
				ui_GameRoom.getPlayerList().get(playerMove.nPosition).chX = playerMove.chX;
				ui_GameRoom.getPlayerList().get(playerMove.nPosition).chY = playerMove.chY;
				ui_GameRoom.getPlayerList().get(playerMove.nPosition).strAnswer = playerMove.strAnswer;
				ui_GameRoom.getPlayerList().get(playerMove.nPosition).nIndex = playerMove.nIndex;
				ui_GameRoom.getPlayerList().get(playerMove.nPosition).nRoom = playerMove.nIndex;
			}
		}
	}

	public void updateRoomInfo(RoomInfo roomInfo) {
		//System.out.println("threadroomInfo: "+roomInfo);
		//System.out.println("threadui_GameRoomInfo: "+ui_GameRoom.getRoomInfo());
		if (roomInfo.bPaly) { // ���� ����
			ui_GameRoom.getRoomInfo().nQuiz = roomInfo.nQuiz;
			ui_GameRoom.getRoomInfo().bPaly = roomInfo.bPaly;
			ui_GameRoom.addPlayer(roomInfo.userInfoList);
		}
	}

	public void chatAnalysis(ChatMessage cMessage) {

		// ��� ������
		if (cMessage.strTo.equals("ALL")) {
			if (cMessage.nRoom == 0) {
				ui_WaitRoom.getJtaWaitchat().append(cMessage.strFrom + ": " + cMessage.strMessage + "\r\n");
				ui_WaitRoom.getJtaWaitchat().setCaretPosition(ui_WaitRoom.getJtaWaitchat().getText().length());
			} else if (cMessage.nRoom == ui_GameRoom.getUserInfo().nRoom) {
				ui_GameRoom.getJtaGameChat().append(cMessage.strFrom + ": " + cMessage.strMessage + "\r\n");
				ui_GameRoom.getJtaGameChat().setCaretPosition(ui_GameRoom.getJtaGameChat().getText().length());
			}
			// �Ӹ��޴� ���
		} else if (cMessage.strTo.equals(ui_WaitRoom.getUserInfo().strNick)) {
			if (ui_WaitRoom.getUserInfo().nRoom == 0) {
				ui_WaitRoom.getJtaWaitchat().append(cMessage.strFrom + ": �Ӹ�����>" + cMessage.strMessage + "\r\n");
				ui_WaitRoom.getJtaWaitchat().setCaretPosition(ui_WaitRoom.getJtaWaitchat().getText().length());
			} else if(cMessage.nRoom == ui_GameRoom.getUserInfo().nRoom){
				ui_GameRoom.getJtaGameChat().append(cMessage.strFrom + ": �Ӹ�����>" + cMessage.strMessage + "\r\n");
				ui_GameRoom.getJtaGameChat().setCaretPosition(ui_GameRoom.getJtaGameChat().getText().length());
			}

			// �Ӹ������� ���
		} else if (cMessage.strFrom.equals(ui_WaitRoom.getUserInfo().strNick)) {
			if (cMessage.nRoom == 0) {
				ui_WaitRoom.getJtaWaitchat().append(cMessage.strTo + ": �Ӹ�����>" + cMessage.strMessage + "\r\n");
				ui_WaitRoom.getJtaWaitchat().setCaretPosition(ui_WaitRoom.getJtaWaitchat().getText().length());
			} else if(cMessage.nRoom == ui_GameRoom.getUserInfo().nRoom){
				ui_GameRoom.getJtaGameChat().append(cMessage.strTo + ": �Ӹ�����>" + cMessage.strMessage + "\r\n");
				ui_GameRoom.getJtaGameChat().setCaretPosition(ui_GameRoom.getJtaGameChat().getText().length());
			}
		}
	}

	public void addPlayer(ArrayList<UserInfo> userInfo) {

		ui_GameRoom.addPlayer(userInfo);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		boolean isStop = false;

		while (!isStop) {
			try {
				socket = main_Client.getSocket();
				Object object = main_Client.getOis().readObject();
				ArrayList<RoomInfo> roomInfo = new ArrayList<RoomInfo>(7);
				ArrayList<UserInfo> userInfo = new ArrayList<UserInfo>();

				// ArrayList
				if (object instanceof ArrayList) {
					ArrayList array = (ArrayList) object;
					// ArrayList<UserInfo>
					if (array.get(0) instanceof UserInfo) {
						userInfo = (ArrayList<UserInfo>) object;
						addPlayer(userInfo);
					}
					// ArrayList<RoomInfo>
					else if (array.get(0) instanceof RoomInfo) {
						// System.out.println("<RoomInfo>");
						roomInfo = (ArrayList<RoomInfo>) object;
						resetRoom(roomInfo);
						resetTable(roomInfo.get(0).userInfoList);
					}
				}
				// UserInfo //�α���
				else if (object instanceof UserInfo) {
					UserInfo user = (UserInfo) object;
					// addPlayer(user);
				} else if (object instanceof PlayerMove) {
					moveCheck((PlayerMove) object);
				}
				// RoomInfo
				else if (object instanceof RoomInfo) {
					updateRoomInfo((RoomInfo) object);
				}
				// ChatMessage
				else if (object instanceof ChatMessage) {
					chatAnalysis((ChatMessage) object);
				}
				// String
				else if (object instanceof String) {

				}

			} catch (Exception e) {
				// TODO: handle exception
				try {
					Thread.sleep(5000);
					e.printStackTrace();
					System.out.println("������ ���������ϴ�.");
					break;
				} catch (Exception e2) {
					// TODO: handle exception
				}

			}
		}
	}
}
