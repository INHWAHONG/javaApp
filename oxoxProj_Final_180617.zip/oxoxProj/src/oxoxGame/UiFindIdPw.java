package oxoxGame;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.plaf.synth.SynthSplitPaneUI;

public class UiFindIdPw extends Frame implements ActionListener{
	JPanel jpnID,jpnTn,jpnName,jpnBtnadd,jpnEn,jpnEmail,jpnBtn2add;
	JPanel jpnPW, jpnPwName,jpnPWid, jpnPWbtn, jpnPWn;
	JTabbedPane jtab;
	JButton btnName,btnEmail,btnPwOk,btnPwCancel;
	JLabel lbNt,lbN,lbEt,lbE,lbPwName,lbPwId;
	JTextField tfN,tfE,tfPwn,tfPwid;
	Font fontT,fontN;
	ChangepwDialog cd;
	UiJoindata uj;
	
	int intindex=-5;
	int idnindex=-1,idpindex=-2,pwidindex=-3,pwnindex=-4;
	private final String PATH = "../oxoxProj/src/oxox.txt";
	 private ArrayList<UiJoindata>list=new ArrayList<UiJoindata>();
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==btnName) {
			try {
				openMember();
				System.out.println(list);
				System.out.println(idnindex);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			idnameSearchIndex();
		if (idnindex==-1) {
			
			JOptionPane.showMessageDialog(null,"�����Ͻ��� ���� ȸ�� �Դϴ�.","���̵� ã��",JOptionPane.WARNING_MESSAGE);
		}else {
			
			JOptionPane.showMessageDialog(null,list.get(idnindex).getName()+"���� ���̵�� "+list.get(idnindex).getId()+"�Դϴ�.","���̵� ã��",JOptionPane.PLAIN_MESSAGE);
		}
		}
		if(e.getSource()==btnEmail) {
			try {
				openMember();
				System.out.println(list);
				System.out.println(idnindex);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			phoneSearchIndex();
		if (idpindex==-2) {
			
			JOptionPane.showMessageDialog(null,"�����Ͻ��� ���� ȸ�� �Դϴ�.","���̵� ã��",JOptionPane.WARNING_MESSAGE);
		}else {
			
			JOptionPane.showMessageDialog(null,list.get(idpindex).getName()+"���� ���̵�� "+list.get(idpindex).getId()+"�Դϴ�.","���̵� ã��",JOptionPane.PLAIN_MESSAGE);
		}
		}
		if(e.getSource()==btnPwOk) {
			try {
				openMember();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			pwidSearchIndex();
			pwnameSearchIndex();
			if (pwidindex==pwnindex) {
				intindex=pwidindex;
				cd=new ChangepwDialog(this);
			}else {
				JOptionPane.showMessageDialog(null,"���̵� �Ǵ� �̸��� �߸��Ǿ����ϴ�.","��й�ȣ ã��",JOptionPane.WARNING_MESSAGE);
			}
		}
		if(e.getSource()==btnPwCancel) {
			this.dispose();
		}
		
	}
	public void pwidSearchIndex() {
		pwidindex=-3;
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).getId().equals(tfPwid.getText().trim())) {
				pwidindex=i;
			}
		}
	}
	public void pwnameSearchIndex() {
		pwnindex=-4;
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).getId().equals(tfPwid.getText().trim())) {
				pwnindex=i;
			}
		}
	}
	public void idnameSearchIndex() {
		idnindex=-1;
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).getName().equals(tfN.getText().trim())) {
				idnindex=i;
				
			}
		}
	}
	public void phoneSearchIndex() {
		idpindex=-2;
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).getPhone().equals(tfE.getText().trim())) {
				idpindex=i;
				
			}
		}
	}

	public void openMember() throws Exception {
		
		ObjectInputStream ois=null;
		try {
			ois=new ObjectInputStream(new FileInputStream(PATH));
			list=(ArrayList<UiJoindata>) ois.readObject();
		} catch (Exception e) {
			// TODO: handle exception
			list=new ArrayList<UiJoindata>();
			try {
				new File(PATH).createNewFile();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally {
			if(ois!=null)ois.close();
		}
	} 
	public void saveMember() {
		ObjectOutputStream oos=null;
		
		try {
			oos=new ObjectOutputStream(new FileOutputStream(PATH));
			oos.writeObject(list);
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			if(oos!=null)
				try {
					oos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	public void initpro() {
		jpnID=new JPanel();
		jpnID.setLayout(new GridLayout(6, 1));
		jpnTn=new JPanel();
		jpnTn.setLayout(new FlowLayout(FlowLayout.LEFT,30,10));
		jpnName=new JPanel();
		jpnName.setLayout(new FlowLayout(FlowLayout.LEFT,30,0));
		jpnBtnadd=new JPanel();
		jpnBtnadd.setLayout(new FlowLayout(FlowLayout.CENTER,0,0));
		jpnEn=new JPanel();
		jpnEn.setLayout(new FlowLayout(FlowLayout.LEFT,30,10));
		jpnEmail=new JPanel();
		jpnEmail.setLayout(new FlowLayout(FlowLayout.LEFT,23,0));
		jpnBtn2add=new JPanel();
		jpnBtn2add.setLayout(new FlowLayout(FlowLayout.CENTER,0,0));
		
		jpnPW=new JPanel();
		jpnPW.setLayout(new GridLayout(4, 1));
		jpnPWn=new JPanel();
		jpnPwName=new JPanel();
		jpnPwName.setLayout(new FlowLayout(FlowLayout.LEFT,30,0));
		jpnPWid=new JPanel();
		jpnPWid.setLayout(new FlowLayout(FlowLayout.LEFT,30,0));
		jpnPWbtn=new JPanel();
		jpnPWbtn.setLayout(new FlowLayout(FlowLayout.CENTER,30,0));
		
		fontT=new Font("����", Font.BOLD, 20);
		fontN=new Font("����", Font.BOLD, 15);
		
		btnName=new JButton("Ȯ��");
		btnName.addActionListener(this);
		btnEmail=new JButton("Ȯ��");
		btnEmail.addActionListener(this);
		btnPwOk=new JButton("Ȯ��");
		btnPwOk.addActionListener(this);
		btnPwCancel=new JButton("���");
		btnPwCancel.addActionListener(this);
		
		lbNt=new JLabel("�̸����� ã��");
		lbNt.setFont(fontT);
		lbNt.setForeground(Color.blue);
		lbN=new JLabel("��   ��");
		lbN.setFont(fontN);
		lbEt=new JLabel("��ȭ��ȣ�� ã��");
		lbEt.setForeground(Color.blue);
		lbEt.setFont(fontT);
		lbE=new JLabel("��ȭ��ȣ");
		lbE.setFont(fontN);
		lbPwName=new JLabel("��   ��");
		lbPwName.setFont(fontN);
		lbPwId=new JLabel("���̵�");
		lbPwId.setFont(fontN);
		jtab=new JTabbedPane();
		
		tfN=new JTextField(20);
		tfE=new JTextField(20);
		tfPwn=new JTextField(20);
		tfPwid=new JTextField(20);
		
		this.add(jtab);
		jpnIDinfo();
		jpnPWinfo();
		jtab.add("���̵� ã��",jpnID);
		jtab.add("��й�ȣ ã��",jpnPW);
		
	}
	public void jpnIDinfo() {
		
		jpnID.add(jpnTn);
		jpnTn.add(lbNt);
		
		jpnID.add(jpnName);
		jpnName.add(lbN);
		jpnName.add(tfN);
		jpnID.add(jpnBtnadd);
		jpnBtnadd.add(btnName);
	
		jpnID.add(jpnEn);
		jpnEn.add(lbEt);
		jpnID.add(jpnEmail);
		jpnEmail.add(lbE);
		jpnEmail.add(tfE);
		jpnID.add(jpnBtn2add);
		jpnBtn2add.add(btnEmail);
	}
	public void jpnPWinfo() {
		jpnPW.add(jpnPWn);
		jpnPW.add(jpnPwName);
		jpnPwName.add(lbPwName);
		jpnPwName.add(tfPwn);
		jpnPW.add(jpnPWid);
		jpnPWid.add(lbPwId);
		jpnPWid.add(tfPwid);
		jpnPW.add(jpnPWbtn);
		jpnPWbtn.add(btnPwOk);
		jpnPWbtn.add(btnPwCancel);
		
	}
	
   public UiFindIdPw() {
	   initpro();
      this.addWindowListener(new WindowAdapter() {

         @Override
         public void windowClosing(WindowEvent e) {
            // TODO Auto-generated method stub
        	 dispose();
         }

      });
      this.setTitle("ID/PW ã��");
      this.setBounds(100, 100, 400, 400);
      this.setVisible(true);
      
   }

   public static void main(String[] args) {
      new UiFindIdPw();
   }

}