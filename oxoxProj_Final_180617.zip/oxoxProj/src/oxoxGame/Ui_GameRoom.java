package oxoxGame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

class PlayerMove implements Serializable {
	int nRoom;
	int nPosition;
	int nIndex;
	int chX;
	int chY;
	String strAnswer;
	UserInfo userInfo;

	public PlayerMove() {
		super();
	}

	public PlayerMove(int nRoom, int nIndex, String strAnswer) {
		super();
		this.nRoom = nRoom;
		this.nIndex = nIndex;
		this.strAnswer = strAnswer;
	}

	public PlayerMove(PlayerMove pMove) {
		super();
		this.nRoom = pMove.nRoom;
		this.nIndex = pMove.nIndex;
		this.nPosition = pMove.nPosition;
		this.chX = pMove.chX;
		this.chY = pMove.chY;
		this.strAnswer = pMove.strAnswer;
		this.userInfo = pMove.userInfo;
	}

	@Override
	public String toString() {
		return "PlayerMove [nRoom=" + nRoom + ", nIndex=" + nIndex + ", chX=" + chX + ", chY=" + chY + ", strAnswer="
				+ strAnswer + "]";
	}
}

public class Ui_GameRoom extends JFrame {

	private JPanel jpnMainPage, jpnTop, jpnMid, jpnBot, jpnChat;
	private JLabel lbMid;
	private int chX, chY;
	private ImageIcon oxWaitImage, ox_o, ox_x;
	private DefaultTableModel model;
	private Main_Client main_Client;
	private Ui_GameRoom ui_GameRoom;
	
	private Thread_Cho cho;

	private int index;
	private int[] nPosition;
	private String choice;
	private String[] strAnswer;
	private String answer = null;
	private UserInfo userInfo = new UserInfo();
	private RoomInfo roomInfo = new RoomInfo();

	private JPanel jpnTime, jpnprofile;
	private JButton jbtnexit;
	private JLabel lbquiz, lbtime, lbprofile, lbcho;

	private ImageIcon quiz, icontime, profile, exit;

	private JPanel pnJtable;
	private JTextArea jtaGameChat, jtaQuest;
	private JScrollPane jspUser, jspChat;
	private JTable jTable;
	private JTextField jtfWaitchat;
	private ChatMessage chatMessage = new ChatMessage();

	private ArrayList<Thread_Move> thread_MoveList = new ArrayList<Thread_Move>();
	private PlayerMove playerMove = new PlayerMove();
	private PlayerMove[] arrPlayerMove = new PlayerMove[20];
	private JLabel[] lbPlayer = new JLabel[20];
	private ArrayList<JLabel> lbPlayerList = new ArrayList<JLabel>();
	private ArrayList<PlayerMove> playerList = new ArrayList<PlayerMove>();

	private String strPATHp1 = this.getClass().getResource("").getPath() + "../image/1.gif";
	private String strPATHp2 = this.getClass().getResource("").getPath() + "../image/2.gif";
	private String strPATHp3 = this.getClass().getResource("").getPath() + "../image/3.gif";
	private String strPATHp4 = this.getClass().getResource("").getPath() + "../image/4.gif";
	private String strPATHp5 = this.getClass().getResource("").getPath() + "../image/5.gif";
	private String strPATHp6 = this.getClass().getResource("").getPath() + "../image/6.gif";
	private String strPATHp7 = this.getClass().getResource("").getPath() + "../image/7.gif";
	private String strPATHp8 = this.getClass().getResource("").getPath() + "../image/8.gif";
	private String strPATHp9 = this.getClass().getResource("").getPath() + "../image/9.gif";
	private String strPATHp10 = this.getClass().getResource("").getPath() + "../image/10.gif";
	private String strPATHp11 = this.getClass().getResource("").getPath() + "../image/11.gif";
	private String strPATHp12 = this.getClass().getResource("").getPath() + "../image/12.gif";
	private String strPATHp13 = this.getClass().getResource("").getPath() + "../image/13.gif";
	private String strPATHp14 = this.getClass().getResource("").getPath() + "../image/14.gif";
	private String strPATHp15 = this.getClass().getResource("").getPath() + "../image/15.gif";
	private String strPATHp16 = this.getClass().getResource("").getPath() + "../image/16.gif";
	private String strPATHp17 = this.getClass().getResource("").getPath() + "../image/17.gif";
	private String strPATHp18 = this.getClass().getResource("").getPath() + "../image/18.gif";
	private String strPATHp19 = this.getClass().getResource("").getPath() + "../image/19.gif";
	private String strPATHp20 = this.getClass().getResource("").getPath() + "../image/20.gif";

	private String[] strPlayer = { strPATHp1, strPATHp2, strPATHp3, strPATHp4, strPATHp5, strPATHp6, strPATHp7,
			strPATHp8, strPATHp9, strPATHp10, strPATHp11, strPATHp12, strPATHp13, strPATHp14, strPATHp15, strPATHp16,
			strPATHp17, strPATHp18, strPATHp19, strPATHp20 };

	private ImageIcon[] iconPlayer = new ImageIcon[20];
	private int nPlayer;

	final static public int CHAT = 0;
	final static public int LOGIN = 1;
	final static public int MOVE = 2;
	final static public int START = 3;
	final static public int EXIT = 4;
	final static public int USERLIST = 5;
	final static public int ROOM = 6;

	public ArrayList<JLabel> getLbPlayerList() {
		return lbPlayerList;
	}

	public ArrayList<PlayerMove> getPlayerList() {
		return playerList;
	}

	public PlayerMove getPlayerMove() {
		return playerMove;
	}

	public ArrayList<Thread_Move> getThread_MoveList() {
		return thread_MoveList;
	}

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public RoomInfo getRoomInfo() {
		return roomInfo;
	}

	public void setRoomInfo(RoomInfo roomInfo) {
		this.roomInfo = roomInfo;
	}

	public Main_Client getMain_Client() {
		return main_Client;
	}

	public Thread_Cho getCho() {
		return cho;
	}

	public void setCho(Thread_Cho cho) {
		this.cho = cho;
	}

	public JLabel getLbcho() {
		return lbcho;
	}

	public JLabel getLbtime() {
		return lbtime;
	}

	public void setLbtime(JLabel lbtime) {
		this.lbtime = lbtime;
	}

	public JTextArea getJtaGameChat() {
		return jtaGameChat;
	}

	public void setJtaGameChat(JTextArea jTextArea) {
		this.jtaGameChat = jTextArea;
	}

	public Ui_GameRoom getUi_GameRoom() {
		return this;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getChoice() {
		return choice;
	}

	public void setChoice(String choice) {
		this.choice = choice;
	}

	public JTextArea getJtaQuest() {
		return jtaQuest;
	}

	public void setJtaQuest(JTextArea jtaQuest) {
		this.jtaQuest = jtaQuest;
	}

	public int getChX() {
		return chX;
	}

	public void setChX(int chX) {
		this.chX = chX;
	}

	public int getChY() {
		return chY;
	}

	public void setChY(int chY) {
		this.chY = chY;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	// public void jtableUpdate(String[][] strArrTemp, int nUserCount) {
	// model.setNumRows(0);// �������̺��� �ʱ�ȭ
	// int nCount=0;
	// for (int i = 0; i < nUserCount; i++) {
	// if (strArrTemp[i][3].equals(userInfo.strRoomName)) {
	// nCount++;
	// model.addRow(strArrTemp[i]);// 0,���̵�,�г���,��ġ ���� �־���
	// model.setValueAt(model.getRowCount(), nCount, 0);// 0�ڸ��� �ش����Ǽ������� �ٲ���
	// }
	// }
	//
	// }

	public void addPlayer() {
		if (nPlayer < 20) {
			lbPlayer[0] = new JLabel();
			iconPlayer[0] = new ImageIcon(new ImageIcon(strPlayer[(int) (Math.random() * (strPlayer.length - 1))])
					.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT));
			lbPlayer[0].setIcon(iconPlayer[0]);

			jpnMid.add(lbPlayer[0]);
			arrPlayerMove[0] = new PlayerMove();
			arrPlayerMove[0].nIndex = 0;
			arrPlayerMove[0].nPosition = 0;
			playerList.add(arrPlayerMove[0]);
			
			initPosi();
			lbPlayer[0].setBounds(chX, chY, iconPlayer[0].getIconWidth(), iconPlayer[0].getIconHeight());
			Thread_Move playerThread = new Thread_Move(this, lbPlayer[0]);
			playerThread.start();
			thread_MoveList.add(playerThread);
			jpnMid.remove(lbMid);
			switch (index) {
			case 0:
				lbMid = new JLabel(oxWaitImage);
				break;
			case 1:
				lbMid = new JLabel(ox_o);
				break;
			case 2:
				lbMid = new JLabel(ox_x);
				break;
			default:
				break;
			}
			jpnMid.add(lbMid);
			lbMid.setBounds(0, 0, jpnMid.getWidth(), jpnMid.getHeight());
		}
	}

	public void addPlayer(ArrayList<UserInfo> userList) {
		nPlayer = userList.size();
		jpnMid.remove(lbPlayer[0]);
		thread_MoveList.get(0).isStop();
		thread_MoveList.remove(0);
		thread_MoveList.clear();
		playerList.remove(0);
		if (nPlayer < 20) {
			for (int i = 0; i < userList.size(); i++) {
				lbPlayerList.add(lbPlayer[i]);
				arrPlayerMove[i] = new PlayerMove();
				arrPlayerMove[i].nIndex = 0;
				arrPlayerMove[i].nPosition = i;
				arrPlayerMove[i].userInfo = userList.get(i);
				playerList.add(arrPlayerMove[i]);

				lbPlayer[i] = new JLabel();
				if (userInfo.strNick.equals(userList.get(i).strNick)) {
					playerMove.nPosition = i;
					iconPlayer[i] = new ImageIcon(
							new ImageIcon(strPlayer[i]).getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT));
				} else {
					iconPlayer[i] = new ImageIcon(
							new ImageIcon(strPlayer[i]).getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
				}
				lbPlayer[i].setIcon(iconPlayer[i]);
				jpnMid.add(lbPlayer[i]);

				initPosi();
				lbPlayer[i].setBounds(chX, chY, iconPlayer[i].getIconWidth(), iconPlayer[i].getIconHeight());
				Thread_Move playerThread = new Thread_Move(this, playerList.get(i), lbPlayer[i]);
				playerThread.start();
				thread_MoveList.add(playerThread);
			}
			jpnMid.remove(lbMid);
			switch (index) {
			case 0:
				lbMid = new JLabel(oxWaitImage);
				break;
			case 1:
				lbMid = new JLabel(ox_o);
				break;
			case 2:
				lbMid = new JLabel(ox_x);
				break;
			default:
				break;
			}
			jpnMid.add(lbMid);
			lbMid.setBounds(0, 0, jpnMid.getWidth(), jpnMid.getHeight());
		}
	}

	public void change(int index) {
		jpnMid.remove(lbMid);
		switch (index) {
		case 0:
			lbMid = new JLabel(oxWaitImage);
			break;
		case 1:
			lbMid = new JLabel(ox_o);
			break;
		case 2:
			lbMid = new JLabel(ox_x);
			break;
		default:
			break;
		}
		jpnMid.add(lbMid);
		lbMid.setBounds(0, 0, jpnMid.getWidth(), jpnMid.getHeight());
	}

	public void initPosi() {
		chX = (int) (Math.random() * 200) + 380; // �ɸ����� �ʱ� ��ġ�� �������� �������ִ� X��ǥ
		chY = (int) (Math.random() * 320); // �ɸ����� �ʱ� ��ġ�� �������� �������ִ� Y��ǥ
	}

	public void textInfo() {// ä��âui
		jtaGameChat = new JTextArea();
		jtfWaitchat = new JTextField();
		jspChat = new JScrollPane(jtaGameChat, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

		jpnChat.add(jtaGameChat);
		jpnChat.add(jtfWaitchat);

		jtaGameChat.setBounds(0, 0, jpnChat.getWidth(), jpnChat.getHeight() - 30);
		jtaGameChat.setText("���ӿ� �����ϼ̽��ϴ�.\r\n");
		jtfWaitchat.setBounds(jtaGameChat.getX(), jtaGameChat.getHeight(), jtaGameChat.getWidth(),
				jpnChat.getHeight() - jtaGameChat.getHeight());

		jtfWaitchat.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub

				playerMove.nRoom = userInfo.nRoom;
				playerMove.userInfo = userInfo;

				try {
					if ((e.getKeyCode() == KeyEvent.VK_F1) || (e.getKeyCode() == 37)) {
						playerMove.nIndex = 1;
						playerMove.strAnswer = "O";
						playerMove.chX = (int) (Math.random() * 310);
						playerMove.chY = (int) (Math.random() * 270);
						PlayerMove pMove = new PlayerMove(playerMove);
						//System.out.println(pMove);
						change(playerMove.nIndex);
						if ((main_Client != null)&&roomInfo.bPaly) {
							main_Client.getOos().writeObject(pMove);
						}
						else {
							if(roomInfo.bPaly) {
								main_Client.getOos().writeObject(pMove);
							}
							else {
								playerList.get(0).chX = playerMove.chX;
								playerList.get(0).chY = playerMove.chY;
								playerList.get(0).nIndex = playerMove.nIndex;
								playerList.get(0).nPosition = 0;
								playerList.get(0).strAnswer = playerMove.strAnswer;
								thread_MoveList.get(0).setPlayerMove(playerMove);
							}
						}
					}

					else if ((e.getKeyCode() == KeyEvent.VK_F2) || (e.getKeyCode() == 39)) {
						playerMove.nIndex = 2;
						playerMove.strAnswer = "X";
						playerMove.chX = (int) (Math.random() * 280) + 680;
						playerMove.chY = (int) (Math.random() * 270);
						PlayerMove pMove = new PlayerMove(playerMove);
						//System.out.println(pMove);
						change(playerMove.nIndex);
						if ((main_Client != null)&&roomInfo.bPaly) {
							main_Client.getOos().writeObject(pMove);
						}
						else {
							if(roomInfo.bPaly) {
								main_Client.getOos().writeObject(pMove);
							}
							else {
								playerList.get(0).chX = playerMove.chX;
								playerList.get(0).chY = playerMove.chY;
								playerList.get(0).nIndex = playerMove.nIndex;
								playerList.get(0).nPosition = 0;
								playerList.get(0).strAnswer = playerMove.strAnswer;
								thread_MoveList.get(0).setPlayerMove(playerMove);
							}
						}
					}

					else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
						chatMessage = new ChatMessage(); // �г������� �ְ�����.
						chatMessage.nType = ROOM;
						chatMessage.nRoom = userInfo.nRoom;
						chatMessage.strFrom = userInfo.strNick;
						if (jtfWaitchat.getText().startsWith("/w")||jtfWaitchat.getText().startsWith("/��")) {
							String[] strSplit = jtfWaitchat.getText().split(" ", 3);
							chatMessage.strTo = strSplit[1];
							chatMessage.strMessage = strSplit[2];
						} else {
							chatMessage.strTo = "ALL";
							chatMessage.strMessage = jtfWaitchat.getText();
						}
						main_Client.getOos().writeObject(chatMessage);
						jtfWaitchat.setText("");
					}
				} catch (Exception e1) {
					// TODO: handle exception
					e1.printStackTrace();
				}
			}
		});
	}
	
	public void centerMove(String strAnswer) {
		//ĳ���� �߾����� �̵����Ѿ���...
		for(int i=0; i<thread_MoveList.size(); i++) {
			if(!strAnswer.equals(thread_MoveList.get(i).getPlayerMove().strAnswer)){
				jpnMid.remove(lbPlayer[i]);//���� ������...
				thread_MoveList.get(i).isStop();
				continue;
			}
			playerList.get(i).nIndex = 3;
			playerList.get(i).strAnswer = null;
			playerList.get(i).chX = (int) (Math.random() * 200) + 380;
			playerList.get(i).chY = (int) (Math.random() * 320);
		}
		change(0);// OX ���� ����
		
	}

	public void quit() {
		UserInfo user = new UserInfo();
		cho.isStop();
		for (int i = 0; i < thread_MoveList.size(); i++) {
			thread_MoveList.get(i).isStop();
		}
		user.nRoom = 0;
		user.strRoomName = "����";
		user.strID = userInfo.strID;
		user.strNick = userInfo.strNick;
		
		try {
			main_Client.getOos().writeObject(user);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.dispose();
		main_Client.getUi_WaitRoom().setVisible(true);
		main_Client.getUi_WaitRoom().setUserInfo(user);
	}

	public void resetTable() {

		for (int i = 0; i < model.getRowCount(); i++) {
			if (!model.getValueAt(i, 3).equals(String.valueOf(userInfo.nRoom))) {
				jTable.removeRowSelectionInterval(i, i);
			}
		}
	}

	public void GamePro() {

		jpnMainPage = new JPanel(null);
		jpnTop = new JPanel(new BorderLayout());
		// jpnTop=new JPanel(null);
		jpnTime = new JPanel(null);
		jpnMid = new JPanel(null);
		jpnBot = new JPanel(null);
		jpnChat = new JPanel(null);
		lbMid = new JLabel();
		jtaQuest = new JTextArea("�����");
		jtaQuest.setFont(new Font(Font.DIALOG, Font.BOLD, 30));
		jtaQuest.setOpaque(false);
		jtaQuest.setFocusable(false);
		jtaQuest.setLineWrap(true);
		jtaQuest.setBounds(207, 45, 797, 120);

		oxWaitImage = new ImageIcon(this.getClass().getResource("").getPath() + "../image/ox_wait.jpg");
		ox_o = new ImageIcon(this.getClass().getResource("").getPath() + "../image/ox_o.jpg");
		ox_x = new ImageIcon(this.getClass().getResource("").getPath() + "../image/ox_x.jpg");

		quiz = new ImageIcon(this.getClass().getResource("").getPath() + "../image/quiz.png");
		lbquiz = new JLabel(quiz);
		jpnTop.add(jtaQuest);
		jpnTop.add(lbquiz);
		jpnTop.setBounds(0, 0, 1050, 200);

		icontime = new ImageIcon(this.getClass().getResource("").getPath() + "../image/TIME.png");
		lbtime = new JLabel(icontime);

		lbcho = new JLabel("00:00", (int) CENTER_ALIGNMENT);
		jpnMainPage.add(jpnTime);
		jpnTime.setBounds(1050, 0, 200, 200);
		lbcho.setBounds(0, jpnTime.getHeight() / 2 - 10, jpnTime.getWidth(), 80);
		lbtime.setBounds(0, 0, jpnTime.getWidth(), jpnTime.getHeight());
		lbcho.setFont(new Font("", Font.PLAIN, 60));

		jpnTime.add(lbcho);
		jpnTime.add(lbtime);

		profile = new ImageIcon(this.getClass().getResource("").getPath() + "../image/pro.jpg");
		lbprofile = new JLabel(profile);
		jpnprofile = new JPanel();
		exit = new ImageIcon(this.getClass().getResource("").getPath() + "../image/exit.jpg");
		jbtnexit = new JButton(exit);
		jbtnexit.setBounds(1050, 800, 200, 50);
		jbtnexit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (JOptionPane.showConfirmDialog(null, "�����Ͻðڽ��ϱ�??", "", JOptionPane.YES_NO_OPTION) == 0) {
					quit();
				}
			}
		});
		jpnMainPage.add(jbtnexit);
		jpnMainPage.add(lbprofile);
		lbprofile.setBounds(1050, 600, 200, 200);
		jpnMid.setBounds(0, 200, 1050, 400);
		jpnMid.setBackground(Color.yellow);
		jpnBot.setBounds(400, 200, 250, 400);
		jpnBot.setBackground(Color.red);
		jpnChat.setBounds(jpnMid.getX(), jpnMid.getY() + jpnMid.getHeight(), jpnMid.getWidth(), 250);

		textInfo();
		jtaGameChat.setFocusable(false);

		jpnMainPage.setBackground(Color.yellow);

		initPosi();

		String[] strColumn = { "No", "���̵�", "�г���", "��ġ" };
		pnJtable = new JPanel(new BorderLayout());
		jTable = new JTable(model);
		jspUser = new JScrollPane(jTable, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);// jsp�����ֱ�
		pnJtable.add(jspUser);// �гο� ���ϱ�
		pnJtable.setBounds(jpnMid.getWidth(), jpnMid.getY(), 200, jpnMid.getHeight());
		jpnMainPage.add(jpnprofile);
		jpnMainPage.add(jpnTop);

		jpnMainPage.add(jpnMid);
		jpnMainPage.add(jpnChat);
		jpnMainPage.add(pnJtable);
		addPlayer();

		this.add(jpnMainPage);
	}

	public Ui_GameRoom() {
		GamePro();
		this.roomInfo.bPaly = false;
		// cho = new Thread_Cho(this);
		// cho.start();

		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub

				if (JOptionPane.showConfirmDialog(null, "�����Ͻðڽ��ϱ�??", "", JOptionPane.YES_NO_OPTION) == 0) {

					quit();
				}
			}
		});
		this.setBounds(350, 0, 1270, 900);
		this.setVisible(true);
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		jtfWaitchat.requestFocus();
	}

	public Ui_GameRoom(Ui_WaitRoom ui_WaitRoom, UserInfo userInfo) {
		this.userInfo = userInfo;
		this.roomInfo.nRoom = userInfo.nRoom;
		this.roomInfo.strRoomName = userInfo.strRoomName;
		this.roomInfo.bPaly = false;
		this.main_Client = ui_WaitRoom.getUiloginMain();
		this.main_Client.getThread_Chat().setUi_GameRoom(this);
		this.model = ui_WaitRoom.getModel();
		this.setTitle(this.userInfo.strRoomName);

		this.main_Client.setUserInfo(this.userInfo);

		GamePro();
		cho = new Thread_Cho(this);
		cho.start();

		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub

				if (JOptionPane.showConfirmDialog(null, "�����Ͻðڽ��ϱ�??", "", JOptionPane.YES_NO_OPTION) == 0) {
					quit();
				}
			}
		});
		this.setBounds(350, 0, 1270, 900);
		this.setVisible(true);
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		jtfWaitchat.requestFocus();
	}

	public static void main(String[] args) {
		new Ui_GameRoom();
	}
}
