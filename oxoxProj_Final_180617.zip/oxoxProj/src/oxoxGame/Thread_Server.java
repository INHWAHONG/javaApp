package oxoxGame;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

import javax.print.attribute.standard.Severity;

public class Thread_Server extends Thread {
	private Main_Server server;
	private ObjectInputStream ois = null;
	private ObjectOutputStream oos = null;
	private Socket socket;
	// private String strID, strPro, strNick;
	private UserInfo userInfo;
	private boolean bLogin;

	final static public int CHAT = 0;
	final static public int LOGIN = 1;
	final static public int MOVE = 2;
	final static public int START = 3;
	final static public int EXIT = 4;
	final static public int USERLIST = 5;
	final static public int GAMEROOM = 6;

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	public Thread_Server(Main_Server server) {
		super();
		this.server = server;
	}

	public void broadCast(Object object) {
		for (Thread_Server a : server.getThreadList()) {
			a.sendMessage(object);
		}
	}

	public void sendMessage(Object object) {
		try {
			oos.writeObject(object);
			oos.flush();
		} catch (Exception e) {
			// TODO Auto-generated catch block
		}
	}

	public void updateRoomInfo(RoomInfo roomInfo) {
		RoomInfo room =  new RoomInfo();
		OxoxZocbo zb = new OxoxZocbo();
		ArrayList<UserInfo> user = new ArrayList<UserInfo>();
		server.roomInfoList.get(roomInfo.nRoom).bPaly = true;
		for(int i=0; i<server.roomInfoList.get(roomInfo.nRoom).userInfoList.size();i++) {
			user.add(server.roomInfoList.get(roomInfo.nRoom).userInfoList.get(i));
		}
		room.bPaly = true;
		room.nQuiz = zb.makeQuiz();
		room.nRoom = roomInfo.nRoom;
		room.strRoomName = roomInfo.strRoomName;
		room.userInfoList = user;
		
		
		//System.out.println("updateRoomInfo: "+room);
		if (roomInfo.bPaly) {// ���� ���� �޼��� ����
			for (int i = 0; i < server.threadList.size(); i++) {// ������� �濡�ִ� ������ ������ �� �� ��ġ�ϸ� ���ӽ��� �޼��� ����
				if(server.threadList.get(i).userInfo.nRoom == roomInfo.nRoom) {
					try {
						server.threadList.get(i).oos.writeObject(room);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
	}

	public void chatAnalysis(ChatMessage cMessage) {
		// ��δ�ȭ
		if (cMessage.strTo.equals("ALL")) {
			for (int i = 0; i < server.getThreadList().size(); i++) {
				server.getThreadList().get(i).sendMessage(cMessage);
			}
		}

		// �Ӹ�������
		else {
			for (int i = 0; i < server.getThreadList().size(); i++) {
				if (cMessage.strFrom.equals(server.getThreadList().get(i).getUserInfo().strNick)) {
					server.getThreadList().get(i).sendMessage(cMessage);
				}
				if (cMessage.strTo.equals(server.getThreadList().get(i).getUserInfo().strNick)) {
					server.getThreadList().get(i).sendMessage(cMessage);
				}
			}
		}
	}

	public void moveCheck(PlayerMove playerMove) {
		for (int i = 0; i < server.threadList.size(); i++) {// ������� �濡�ִ� ������ ���ȣ �� �� ��ġ�ϸ� ���ӽ��� �޼��� ����
			if (server.threadList.get(i).userInfo.nRoom == playerMove.nRoom) {
				try {
					//System.out.println(i+"��° ����: "+server.threadList.get(i).userInfo);
					server.threadList.get(i).oos.writeObject(playerMove);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public void addUser(UserInfo userInfo) {
		try {
			if (bLogin == false) {// �α��� ���� ����
				this.userInfo = userInfo;
				bLogin = true;
			}
			int nRoom = userInfo.nRoom;
			if (nRoom == 0) {				
				if (server.roomInfoList.get(0).userInfoList.size() == 0) {// ���� ������ ������. ���� �߰�
					server.roomInfoList.get(0).userInfoList.add(userInfo);
				} else {// ���� ������ ������
					for (int i = 0; i < server.roomInfoList.size(); i++) {// 0~7����˻�
						if (i == 0) {// ���� ���� �˻� �� ������Ʈ
							boolean bCheck = false;
							for (int j = 0; j < server.roomInfoList.get(i).userInfoList.size(); j++) {
								if (userInfo.strID.equals(server.roomInfoList.get(i).userInfoList.get(j).strID)) {
									bCheck = true;
									server.roomInfoList.get(0).userInfoList.get(j).strID = userInfo.strID;
									server.roomInfoList.get(0).userInfoList.get(j).strNick = userInfo.strNick;
									server.roomInfoList.get(0).userInfoList.get(j).nRoom = userInfo.nRoom;
									server.roomInfoList.get(0).userInfoList.get(j).strRoomName = userInfo.strRoomName;
								}
							}
							if (!bCheck) {
								server.roomInfoList.get(0).userInfoList.add(userInfo);
							}

						} else {// ���ӷ� �˻� �� ����
							for (int j = 0; j < server.roomInfoList.get(i).userInfoList.size(); j++) {
								if (userInfo.strID.equals(server.roomInfoList.get(i).userInfoList.get(j).strID)) {
									server.roomInfoList.get(i).userInfoList.remove(j);
									continue;
								}
							}
						}
					}
				}
			} else {// 0~7 ���ӷ� ����� �߰�
				if (server.roomInfoList.get(nRoom).strRoomName.equals("���")) {// ����϶� ���̸�/����� �߰�
					server.roomInfoList.get(nRoom).strRoomName = userInfo.strRoomName;
					server.roomInfoList.get(nRoom).userInfoList.add(userInfo);
					for (int i = 0; i < server.threadList.size(); i++) {
						if (server.threadList.get(i).userInfo.strNick.equals(userInfo.strNick)) {
							server.threadList.get(i).oos.writeObject(userInfo);
							//System.out.println("������_" + userInfo);
						}
					}
				} else {// ���� �����Ҷ� ����ڸ� �߰�
					server.roomInfoList.get(nRoom).userInfoList.add(userInfo);// �������� �߰�
					//System.out.println(userInfo);

				}
				for (int i = 0; i < server.roomInfoList.get(0).userInfoList.size(); i++) {
					if (userInfo.strID.equals(server.roomInfoList.get(0).userInfoList.get(i).strID)) {
						server.roomInfoList.get(0).userInfoList.get(i).strID = userInfo.strID;
						server.roomInfoList.get(0).userInfoList.get(i).strNick = userInfo.strNick;
						server.roomInfoList.get(0).userInfoList.get(i).nRoom = userInfo.nRoom;
						server.roomInfoList.get(0).userInfoList.get(i).strRoomName = userInfo.strRoomName;
						continue;
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		boolean isStop = false;
		try {
			System.out.println("run");
			socket = server.getSocket();
			ois = new ObjectInputStream(socket.getInputStream());
			oos = new ObjectOutputStream(socket.getOutputStream());
			while (!isStop) {
				Object object = ois.readObject();

				// ArrayList
				if (object instanceof ArrayList) {
					ArrayList array = (ArrayList) object;
					// ArrayList<UserInfo>
					if (array.get(0) instanceof UserInfo) {

					}
					// ArrayList<RoomInfo>
					else if (array.get(0) instanceof RoomInfo) {

					}
				}
				// UserInfo //�α���
				else if (object instanceof UserInfo) {
					addUser((UserInfo) object);

				}
				// PlayerMove //�̵� üũ
				else if (object instanceof PlayerMove) {
					moveCheck((PlayerMove) object);
				}
				// RoomInfo
				else if (object instanceof RoomInfo) {
					updateRoomInfo((RoomInfo) object);
				}
				// ChatMessage
				else if (object instanceof ChatMessage) {
					chatAnalysis((ChatMessage) object);
				}
				// String
				else if (object instanceof String) {

				}

			}
		} catch (

		Exception e) {
			// TODO: handle exception
			// e.printStackTrace();
		}
	}

}
