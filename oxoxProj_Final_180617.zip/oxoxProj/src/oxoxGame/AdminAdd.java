
// pp4.add(Box.createVerticalStrut(50));
//pp4.add(Box.createVerticalStrut(200));
package oxoxGame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import java.awt.Font;



public class AdminAdd extends Frame implements ActionListener{
   JPanel jpn, jpnTitle, jpnName, jpnId, jpnPw,jpnPhone,jpnNick, jpnBtn;
   JButton jbtnCheck,jbtnOk,jbtnCancel;
   JTextField tfName,tfId,tfPw,tfPhone,tfNickname;
   JLabel lbTitle, labelName, lbId, lbPw, lbPhone, lbNick;
   Font fontT, fontN;
   String testid=null;
   int k=0;
   private final String PATH = "../oxoxProj/src/oxox.txt";
   private ArrayList<UiJoindata>list=new ArrayList<UiJoindata>();
   UiJoindata uid;
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==jbtnCheck) {
			try {
				openMember();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			iddoublecheck();
			if(k==-1) {
				JOptionPane.showMessageDialog(null,"���̵� �ߺ��Ǿ����ϴ�.","���̵� �ߺ� üũ",JOptionPane.WARNING_MESSAGE);
			}
			else {
			JOptionPane.showMessageDialog(null,"��밡���� ���̵��Դϴ�.","���̵� �ߺ� üũ",JOptionPane.PLAIN_MESSAGE);
			}
		}
		if(e.getSource()==jbtnOk) {
			try {
				openMember();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			joinMember();
			saveMember();
			JOptionPane.showMessageDialog(null,"�߰��Ǿ����ϴ�","admin",JOptionPane.PLAIN_MESSAGE);
			this.dispose();
			AdminMember m1=new AdminMember();
			
		}
		
		if(e.getSource()==jbtnCancel) {	
			this.dispose();
			AdminMember m1=new AdminMember();
		}
	}
	public int iddoublecheck() {
		testid=tfPw.getText().trim();
		
		for (int i = 0; i < list.size(); i++) {
			if(list.get(i).getId().trim().equals(tfId.getText().trim())){
				return k=-1;
				}
			
		}
		return k=0;
	}
	public void joinMember() {
		uid=new UiJoindata();
		uid.setId(tfId.getText().trim());
		uid.setName(tfName.getText().trim());
		uid.setPw(tfPw.getText().trim());
		uid.setPhone(tfPhone.getText().trim());
		uid.setNickname(tfNickname.getText().trim());
		
		list.add(uid);
		System.out.println(list);
		
	}
	public void saveMember() {
		ObjectOutputStream oos=null;
		
		try {
			oos=new ObjectOutputStream(new FileOutputStream(PATH));
			oos.writeObject(list);
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			if(oos!=null)
				try {
					oos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	public void openMember() throws Exception {
		
		ObjectInputStream ois=null;
		try {
			ois=new ObjectInputStream(new FileInputStream(PATH));
			list=(ArrayList<UiJoindata>) ois.readObject();
		} catch (Exception e) {
			// TODO: handle exception
			list=new ArrayList<UiJoindata>();
			try {
				new File(PATH).createNewFile();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}finally {
			if(ois!=null)ois.close();
		}
	} 
  
public void initPro() {
      jpn=new JPanel();
      jpn.setLayout(new BoxLayout(jpn,BoxLayout.Y_AXIS));
      jpnTitle=new JPanel();
      jpnTitle.setLayout(new FlowLayout(FlowLayout.CENTER,0,20));
      jpnName=new JPanel();
      jpnName.setLayout(new FlowLayout(FlowLayout.LEFT,30,0));
      jpnId=new JPanel();
      jpnId.setLayout(new FlowLayout(FlowLayout.LEFT,30,0));
      jpnPw=new JPanel();
      jpnPw.setLayout(new FlowLayout(FlowLayout.LEFT,30,0));
      jpnPhone=new JPanel();
      jpnPhone.setLayout(new FlowLayout(FlowLayout.LEFT,25,0));
      jpnNick=new JPanel();
      jpnNick.setLayout(new FlowLayout(FlowLayout.LEFT,25,0));
      jpnBtn=new JPanel();
      jpnBtn.setLayout(new FlowLayout(FlowLayout.CENTER,40,0));
      jbtnCheck=new JButton();
      jbtnOk=new JButton();
      jbtnCancel=new JButton();
      tfName=new JTextField(20);
      tfId=new JTextField(20);
      tfPw=new JPasswordField(20);
      tfPhone=new JTextField(20);
      tfNickname=new JTextField(20);
      lbTitle=new JLabel("ȸ���߰�");
      fontT=new Font("����", Font.BOLD, 25);
      labelName=new JLabel("Name");
      fontN=new Font("����", Font.BOLD, 15);
      lbId=new JLabel("   ID ");
      lbPw=new JLabel("  PW");
      lbPhone=new JLabel("Phone");
      lbNick=new JLabel("�г���");
      
      
      
      jpninfo();
      titleinfo();
      nameinfo();
      idinfo();
      pwinfo();
      phoneinfo();
      addressinfo();
      buttoninfo();
      
      this.add(jpn);
      
      
   }
   public void jpninfo() {
      jpn.add(jpnTitle);
	  jpn.add(jpnName);
      jpn.add(jpnId);
      jpn.add(jpnNick);
      jpn.add(jpnPw);
      jpn.add(jpnPhone);
      jpn.add(jpnBtn);
      
   }
   public void buttoninfo() {
	   jbtnOk.setText("Ȯ  ��");
	   jbtnOk.addActionListener(this);
	   jbtnCancel.setText("��  ��");
	   jbtnCancel.addActionListener(this);
	   jpnBtn.add(jbtnOk);
	   jpnBtn.add(jbtnCancel);
	   
   }
   public void addressinfo() {
	   lbNick.setFont(fontN);
	   jpnNick.add(lbNick);
	   jpnNick.add(tfNickname);
   }
   public void phoneinfo() {
	   lbPhone.setFont(fontN);
	   jpnPhone.add(lbPhone);
	   jpnPhone.add(tfPhone);
   }
   public void pwinfo() {
	   lbPw.setFont(fontN);
	   jpnPw.add(lbPw);
	   jpnPw.add(tfPw);
	   
   }
   public void idinfo() {
	   lbId.setFont(fontN);
	   jpnId.add(lbId);
	   jpnId.add(tfId);
	   jbtnCheck.setText("�ߺ�Ȯ��");
	   jbtnCheck.addActionListener(this);
	   jpnId.add(jbtnCheck);
   }
   public void nameinfo() {
	   labelName.setFont(fontN);
	   jpnName.add(labelName);
	   jpnName.add(tfName);
	   
   }
   public void titleinfo() {
	   lbTitle.setFont(fontT);
	   lbTitle.setForeground(Color.black);
	   jpnTitle.add(lbTitle);
   }
   
   public AdminAdd() {
	   setTitle("�߰�");
      initPro();
      //initPro();
      this.addWindowListener(new WindowAdapter() {

         @Override
         public void windowClosing(WindowEvent e) {
            // TODO Auto-generated method stub
            dispose();
         }

      });
      this.pack();
      this.setBounds(100, 100, 500, 500);
      this.setVisible(true);
   }

   public static void main(String[] args) {
      new AdminAdd();
   }

}