package sist.com.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.dao.support.DaoSupport;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;

import sist.com.bean.Customer;
import sist.com.bean.MnoPoster;
import sist.com.bean.Movie;
import sist.com.bean.MovieTicket;
import sist.com.bean.ReviewBean;
import sist.com.bean.SnackBean;
import sist.com.bean.Ticket;
import sist.com.bean.TlocationBean;
import sist.com.dao.CustomerDao;
import sist.com.dao.MovieDao;
import sist.com.dao.MovieTicketDao;
import sist.com.dao.ReviewDao;
import sist.com.dao.SeatDao;
import sist.com.dao.SnackDao;
import sist.com.dao.TicketDao;
import sist.com.dao.TimeDao;
import sist.com.dao.TlocationDao;
import sist.com.dao.ZipcodeDao;

@Controller
public class MainController {
	@Resource(name = "ReviewDao")
	private ReviewDao reviewdao;
	@Resource(name = "MovieDao")
	private MovieDao moviedao;
	@Resource(name = "CustomerDao")
	private CustomerDao customerdao;
	@Resource(name = "TlocationDao")
	private TlocationDao tlocationdao;
	@Resource(name = "SnackDao")
	private SnackDao snackdao;
	@Resource(name="TicketDao")
	private TicketDao ticketdao;
	@Resource(name="TimeDao")
	private TimeDao timedao;
	@Resource(name="ZipcodeDao")
	private ZipcodeDao zipcodedao;
	@Resource(name="SeatDao")
	private SeatDao seatdao;
	@Resource(name="MovieTicketDao")
	   private MovieTicketDao movieTicketdao;
	
	@RequestMapping(value = "movieApp/jsp/infoMovie.do")
	public ModelAndView infoMovie(String mno) {
		ModelAndView mv = new ModelAndView();
		Movie listMovie = moviedao.getMovie(mno);
		mv.addObject("listMovie", listMovie);
		mv.setViewName("movieApp/jsp/speMovie");
		return mv;
	}

	@RequestMapping(value = "movieApp/jsp/main.do")
	public ModelAndView mainStart() {
		ModelAndView mv = new ModelAndView();
		List<Movie> mplayer = moviedao.getMplay();
		List<MnoPoster> currentm = moviedao.getCurrentMovie();
		List<MnoPoster> planm = moviedao.getPlanMovie();
		mv.addObject("mplayer", mplayer);
		mv.addObject("currentm", currentm);
		mv.addObject("planm", planm);
		mv.setViewName("movieApp/jsp/main");
		return mv;
	}

	@RequestMapping(value = "movieApp/jsp/loginPro.do")
	public ModelAndView loginProcess(String cid, String cpassword, HttpSession session) {
		ModelAndView mv = new ModelAndView();
		if (customerdao.loginCheck(cid, cpassword)) {
			String cname = customerdao.selectName(cid);
			session.setAttribute("cName", cname);
			session.setAttribute("cid", cid);
			if(cid.equals("ADMIN")) {
				mv.setViewName("redirect:admin.do?id="+cid);
				return mv;
			}else {
			mv.setViewName("redirect:main.do");
			return mv;
			}
		} else {
		
			mv.setViewName("redirect:main.do");
			
			return mv;
		}
	}
	@RequestMapping(value="movieApp/jsp/admin.do")
	public ModelAndView adminPage(String id) {
		ModelAndView mv = new ModelAndView();
		List<Customer>list=null;
				list=customerdao.customerAll();
		List<Ticket>tlist=null;
		tlist=ticketdao.allTicket();
		mv.addObject("sales", ticketdao.allSumPrice());
		mv.addObject("customer",list);
		mv.addObject("ticket", tlist);
		mv.setViewName("movieApp/jsp/adminpage");
		return mv;
	}
	@RequestMapping(value="movieApp/jsp/logout.do")
	public String logout(HttpSession session) {
		session.setAttribute("cid", null);
		session.setMaxInactiveInterval(0);
		return "redirect:main.do";
	}
	@RequestMapping(value = "movieApp/jsp/leftMain.do")
	public ModelAndView leftMain() {
		ModelAndView mv = new ModelAndView();
		List<ReviewBean> rank = reviewdao.selectRank();
		List<ReviewBean> movierank = reviewdao.selectMovieRank();
		mv.addObject("rank", rank);
		mv.addObject("movierank", movierank);
		mv.setViewName("movieApp/jsp/lefttool");
		return mv;
	}

	@RequestMapping(value = "movieApp/jsp/currentMovie.do")
	public ModelAndView currentMovie() {
		ModelAndView mv = new ModelAndView();
		List<MnoPoster> currentm = moviedao.getCurrentMovie();
		mv.addObject("currentm", currentm);
		mv.setViewName("movieApp/jsp/currentMovie");
		return mv;
	}

	@RequestMapping(value = "movieApp/jsp/planMovie.do")
	public ModelAndView planMovie() {
		ModelAndView mv = new ModelAndView();
		List<MnoPoster> currentm = moviedao.getPlanMovie();
		mv.addObject("currentm", currentm);
		mv.setViewName("movieApp/jsp/currentMovie");
		return mv;
	}

	@RequestMapping(value = "movieApp/jsp/cinemaInfo.do")
	public ModelAndView cinemaInfo(String tdeptno) {
		ModelAndView mv = new ModelAndView();
		int no = Integer.parseInt(tdeptno);
		TlocationBean tlocation = tlocationdao.selectInfo1(no);
		mv.addObject("tlocation", tlocation);
		System.out.println(tlocation);
		mv.setViewName("movieApp/jsp/cinemaInfo");
		return mv;
	}

	@RequestMapping(value = "movieApp/jsp/joinGo.do")
	public String joinGo() {
		return "movieApp/jsp/join";
	}

	@RequestMapping(value = "movieApp/jsp/movieReview.do")
	public ModelAndView movieReview(String query, String data) {
		System.out.println("query = " + query + "data = " + data);
		ModelAndView mv = new ModelAndView();
		HashMap<String, Object> map = new HashMap<String, Object>();
		if (query != null && data != null) {
			map.put("query", query);
			map.put("data", data);
		}
		List<ReviewBean> reviewList = reviewdao.selectBoard(map);
		mv.setViewName("movieApp/jsp/movieReview");
		mv.addObject("review", reviewList);
		return mv;
	}

	@RequestMapping(value = "movieApp/jsp/snackmain.do")
	public ModelAndView snackMain(String snack, @RequestParam(value="query",required=false) String query) {
		ModelAndView mv = new ModelAndView();
		int no = Integer.parseInt(snack);
		if (snack == null) {
			mv.addObject("snack", no);
		} else {
			mv.addObject("snack", no);
		}
		int deptno = Integer.parseInt(query);
		HashMap<String, Integer>map = new HashMap<String, Integer>();
		map.put("deptno", deptno);
		System.out.println(deptno+"---------------------"+map.get("deptno"));
		mv.addObject("snackList", snackdao.selectSnack(map));
		mv.setViewName("movieApp/jsp/snackmain");
		return mv;
	}
	@RequestMapping(value="movieApp/jsp/movieRedit.do")
	public ModelAndView movieRedit() {
		ModelAndView mv = new ModelAndView();
		List<Movie>list = moviedao.getMname();
		mv.addObject("movie", list);
		mv.setViewName("movieApp/jsp/movieRedit");
		return mv;
	}
	@RequestMapping(value="movieApp/jsp/movieReditinsert.do")
	public ModelAndView reviewInsert(ReviewBean review) {
		ModelAndView mv = new ModelAndView();
		review.setMno(moviedao.getMno(review.getMtitle()));
		reviewdao.insertBoard(review);
		mv.setViewName("redirect:movieReview.do");
		return mv;
	}
	
	@RequestMapping(value="movieApp/jsp/myinfo.do")
	public ModelAndView myinfoGo(String cid) {
		ModelAndView mv = new ModelAndView();
		List<Ticket> ticketlist = ticketdao.getTicket(cid);
		ArrayList<Integer> ticketprice = new ArrayList<Integer>();
		int point=customerdao.selectCpoint(cid);
	    String level=customerdao.cLevel(cid);
		mv.addObject("ticketlist",ticketlist);
		mv.addObject("point",point);
		mv.addObject("level",level);
		mv.setViewName("movieApp/jsp/MyInfo");
		return mv;
	}
	
	@RequestMapping(value="movieApp/jsp/idcheck.do")
	public ModelAndView idcheckOpen() {
		ModelAndView mv = new ModelAndView();
		String cid = null;
		mv.addObject("cid",cid);
		mv.addObject("flag",false);
		mv.setViewName("movieApp/jsp/idcheck");
		return mv;
	}
	@RequestMapping(value="movieApp/jsp/idSelect.do")
	public ModelAndView idSeelct(String cid) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("cid",cid);
		mv.addObject("flag",customerdao.idCheck(cid));
		mv.setViewName("movieApp/jsp/idcheck");
		return mv;
	}
	
	@RequestMapping(value="movieApp/jsp/dongSelect.do")
	public ModelAndView dongSelect(String dong) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("dong", zipcodedao.getDong(dong));
		mv.setViewName("movieApp/jsp/address");
		return mv;
	}
	@RequestMapping(value="movieApp/jsp/insertCustomer.do")
	public String insertCustomer(Customer customer) {
		customerdao.insertCustomer(customer);
		return "redirect:main.do";
	}
	
	@RequestMapping(value="movieApp/jsp/findIdPw.do")
	public String findIdPwGo(Model model) {
		model.addAttribute("hide",null);
		return "movieApp/jsp/findIdPw";
	}
	
	@RequestMapping(value="movieApp/jsp/idFindselect.do")
	public ModelAndView idfind(Customer customer) {
		ModelAndView mv = new ModelAndView();
		String cid = customerdao.findId(customer);
		mv.setViewName("movieApp/jsp/findIdPw");
		mv.addObject("hide", "hide");
		mv.addObject("cc", "hide");
		mv.addObject("chide", "hide");
		mv.addObject("cid", cid);
		return mv;
	}
	@RequestMapping(value="movieApp/jsp/pwFindselect.do")
	public ModelAndView pwfind(Customer customer) {
		ModelAndView mv =new ModelAndView();
		String cpw = customerdao.findPw(customer);
		System.out.println("==================="+cpw+"======="+customer.getCid()+"=======");
		mv.addObject("cc",null);
		mv.addObject("hide", "hide");
		mv.addObject("chide",null);
		mv.addObject("cpw", cpw);
		mv.addObject("pid", customer.getCid());
		mv.setViewName("movieApp/jsp/findIdPw");
		return mv;
	}
	
	@RequestMapping(value="movieApp/jsp/pwUpdate.do")
	public String pwUpdate(String cpassword,String pid,Model model) {
		HashMap<Object,Object>map = new HashMap<Object,Object>();
		map.put("pw", cpassword);
		map.put("id",pid);
		customerdao.updatePass(map);
		model.addAttribute("update","update");
		return "movieApp/jsp/findIdPw";
	}
	
	
	
	@RequestMapping(value="movieApp/jsp/seatGo.do")
	public ModelAndView seatGo(Ticket ticket) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("ticket",ticket);
		mv.addObject("poster",moviedao.getSeatPoster(ticket.getTitle()));
		mv.addObject("tseat", movieTicketdao.selectSeat(ticket));
		mv.setViewName("movieApp/jsp/seat");
		return mv;
	}
	@RequestMapping(value="movieApp/jsp/ticket.do")
	   public ModelAndView ticketGo() {
	      ModelAndView mv = new ModelAndView();
	      mv.addObject("mlist",moviedao.getMovieAge());
	      mv.addObject("tlocation", tlocationdao.selectAll());
	      mv.addObject("time",movieTicketdao.selectDay());
	      mv.addObject("tlist",timedao.timeList());
	      mv.setViewName("movieApp/jsp/ticket");
	      return mv;
	   }
	@RequestMapping(value="movieApp/jsp/payGo.do")
	public ModelAndView payGo(Ticket ticket) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("ticket",ticket);
		mv.addObject("poster",moviedao.getSeatPoster(ticket.getTitle()));
		mv.addObject("point",customerdao.selectCpoint(ticket.getId()));
		mv.setViewName("movieApp/jsp/pay");
		return mv;
	}
	@RequestMapping(value="movieApp/jsp/movieRinfo.do")
	public ModelAndView reviewInfo(int no, String mtitle) {
		ModelAndView mv=new ModelAndView();
		mv.addObject("no", reviewdao.selectInfoBoard(no));
		mv.addObject("poster", moviedao.getSeatPoster(mtitle));
		mv.setViewName("movieApp/jsp/movieRinfo");
		return mv;
	}
	@RequestMapping(value="movieApp/jsp/reviewDelte.do")
	public String reviewDelete(int no) {
		reviewdao.deleteBoard(""+no);
		return "redirect:movieReview.do";
	}
	@RequestMapping(value="movieApp/jsp/movieRmodedit.do")
	public ModelAndView reviewMod(int no) {
		ModelAndView mv=new ModelAndView();
		List<Movie>list = moviedao.getMname();
		mv.addObject("movie", list);
		mv.addObject("no", reviewdao.selectInfoBoard(no));
		mv.setViewName("movieApp/jsp/movieRmodedit");
		return mv;
	}
	@RequestMapping(value="movieApp/jsp/movieRupdate.do")
	public String reviewUpdate(ReviewBean review) {
		review.setMno(moviedao.getMno(review.getMtitle()));
		reviewdao.updatemod(review);
		return "redirect:movieReview.do";
	}
	@RequestMapping(value="movieApp/jsp/ticketInsert.do")
	public String ticketInsert(Ticket ticket) {
		String seat[]=ticket.getSeat().split(" ");
		int seatnum=seat.length;
	    int price=timedao.ticektPrice(ticket.getTime());
		ticket.setPrice((seatnum*price)-ticket.getUsepoint());
		ticketdao.insertTicket(ticket);
		System.out.println(ticket);
		seatdao.updateReserve(ticket.getSeat(),ticket);
		System.out.println("usepoint="+ticket.getUsepoint());
		String id=ticket.getId();
		int csum=ticketdao.selectSumPrice(ticket.getId());
		int cpoint1=customerdao.selectCpoint(ticket.getId());
		int cpoint=((seatnum*price/100)+cpoint1-ticket.getUsepoint());
		String clevel=customerdao.cLevel(ticket.getId());
		System.out.println(clevel);
        HashMap<Object, Object>map1=new HashMap<Object, Object>();
         map1.put("cid", id);
         map1.put("cpoint", cpoint);
         map1.put("clevel", clevel);
         map1.put("csum", csum);
         customerdao.updateCustomer(map1);
		
		return "redirect:main.do";
	}
	@RequestMapping(value="movieApp/jsp/delete.do")
	public String Myinfodelete(int no) {
		Ticket ticket=new Ticket();
		ticket=ticketdao.selectTicket(no);
		String seat[]=ticket.getSeat().split(" ");
		  int price=timedao.ticektPrice(ticket.getTime());
		  int seatnum=seat.length;
		  int price2=seatnum*price;
		seatdao.eraseReserve(ticket.getSeat(),ticket);
		int csum=ticketdao.selectSumPrice(ticket.getId())-ticket.getPrice();
		int cpoint1=price2-ticket.getPrice();
		System.out.println("cpoint1="+cpoint1);
		int cpoint=customerdao.selectCpoint(ticket.getId())-(price2/100)+cpoint1;
		System.out.println("cpoint="+cpoint);
		String clevel=customerdao.cLevel(ticket.getId());
		String id=ticket.getId();
		 HashMap<Object, Object>map1=new HashMap<Object, Object>();
         map1.put("cid", id);
         map1.put("cpoint", cpoint);
         map1.put("clevel", clevel);
         map1.put("csum", csum);
         customerdao.updateCustomer(map1);
         ticketdao.deleteTicket(no);
         return "redirect:main.do";
	}
	   @RequestMapping(value="movieApp/jsp/snackInfo.do")
	   public String snackInfo(Model model, int sno) {
	      model.addAttribute("snack",snackdao.selectOne(sno));
	      return "movieApp/jsp/snackInfo";
	   }
	   @RequestMapping(value="movieApp/jsp/poster.do")
	   @ResponseBody
	   public String posterM(String mname) {
	      return moviedao.getSeatPoster(mname);
	   }
}
