package sist.com.bean;

public class DayBean {
	
	private String tday;

	@Override
	public String toString() {
		return "DayBean [tday=" + tday + "]";
	}

	public String getTday() {
		return tday;
	}

	public void setTday(String tday) {
		this.tday = tday;
	}
	
}
