package sist.com.bean;

public class SnackBean {
	private int rm;
	private int    sno;
	private String sname;
	private String sitem;
	private int    sprice;
	private String scontent;
	private String sorin;
	private String simg;
	private int sdeptno;
	
	public int getRm() {
		return rm;
	}

	public void setRm(int rm) {
		this.rm = rm;
	}

	public int getSdeptno() {
		return sdeptno;
	}

	public void setSdeptno(int sdeptno) {
		this.sdeptno = sdeptno;
	}

	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSitem() {
		return sitem;
	}

	public void setSitem(String sitem) {
		this.sitem = sitem;
	}

	public int getSprice() {
		return sprice;
	}

	public void setSprice(int sprice) {
		this.sprice = sprice;
	}

	public String getScontent() {
		return scontent;
	}

	public void setScontent(String scontent) {
		this.scontent = scontent;
	}

	public String getSorin() {
		return sorin;
	}

	public void setSorin(String sorin) {
		this.sorin = sorin;
	}

	public String getSimg() {
		return simg;
	}

	public void setSimg(String simg) {
		this.simg = simg;
	}

	@Override
	public String toString() {
		return "SnackBean [rm=" + rm + ", sno=" + sno + ", sname=" + sname + ", sitem=" + sitem + ", sprice=" + sprice
				+ ", scontent=" + scontent + ", sorin=" + sorin + ", simg=" + simg + ", sdeptno=" + sdeptno + "]";
	}

	
}
