package sist.com.bean;

public class TimeBean {
private int tno;
private String ttime;
private int tprice;
public int getTno() {
	return tno;
}
public void setTno(int tno) {
	this.tno = tno;
}
public String getTtime() {
	return ttime;
}
public void setTtime(String ttime) {
	this.ttime = ttime;
}
public int getTprice() {
	return tprice;
}
public void setTprice(int tprice) {
	this.tprice = tprice;
}
@Override
public String toString() {
	return "TImeBean [tno=" + tno + ", ttime=" + ttime + ", tprice=" + tprice + "]";
}

}
