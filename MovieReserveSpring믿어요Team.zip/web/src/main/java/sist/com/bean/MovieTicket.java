package sist.com.bean;

public class MovieTicket {

	private int rm;
	private String title;
	private String tdate;
	private String theater;
	private String time;
	private String sno; 
	private String seat;
	@Override
	public String toString() {
		return "MovieTicket [rm=" + rm + ", title=" + title + ", tdate=" + tdate + ", theater=" + theater + ", time="
				+ time + ", sno=" + sno + ", seat=" + seat + "]";
	}
	public int getRm() {
		return rm;
	}
	public void setRm(int rm) {
		this.rm = rm;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTdate() {
		return tdate;
	}
	public void setTdate(String tdate) {
		this.tdate = tdate;
	}
	public String getTheater() {
		return theater;
	}
	public void setTheater(String theater) {
		this.theater = theater;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getSno() {
		return sno;
	}
	public void setSno(String sno) {
		this.sno = sno;
	}
	public String getSeat() {
		return seat;
	}
	public void setSeat(String seat) {
		this.seat = seat;
	}
	
	
}
