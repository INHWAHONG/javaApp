package sist.com.bean;

public class Movie {
private String mno;
private String mname;
private int    mrunning;
private String mdir;
private String mactor;
private String mdate;
private String mstory;
private String mplay;
private String magecode;
private String genno;
private String photo1;
private String photo2;
private String photo3;
private String poster;
private String agephoto;




public Movie() {
	super();
}



public Movie(String mno, String mname, int mrunning, String mdir, String mactor, String mdate, String mstory,
		String mplay, String magecode, String genno, String photo1, String photo2, String photo3, String poster,
		String agephoto) {
	super();
	this.mno = mno;
	this.mname = mname;
	this.mrunning = mrunning;
	this.mdir = mdir;
	this.mactor = mactor;
	this.mdate = mdate;
	this.mstory = mstory;
	this.mplay = mplay;
	this.magecode = magecode;
	this.genno = genno;
	this.photo1 = photo1;
	this.photo2 = photo2;
	this.photo3 = photo3;
	this.poster = poster;
	this.agephoto = agephoto;
}



public String getAgephoto() {
	return agephoto;
}



public void setAgephoto(String agephoto) {
	this.agephoto = agephoto;
}



public String getPoster() {
	return poster;
}
public void setPoster(String poster) {
	this.poster = poster;
}
public String getPhoto1() {
	return photo1;
}
public void setPhoto1(String photo1) {
	this.photo1 = photo1;
}
public String getPhoto2() {
	return photo2;
}
public void setPhoto2(String photo2) {
	this.photo2 = photo2;
}
public String getPhoto3() {
	return photo3;
}
public void setPhoto3(String photo3) {
	this.photo3 = photo3;
}
public String getMno() {
	return mno;
}
public void setMno(String mno) {
	this.mno = mno;
}
public String getMname() {
	return mname;
}
public void setMname(String mname) {
	this.mname = mname;
}
public int getMrunning() {
	return mrunning;
}
public void setMrunning(int mrunning) {
	this.mrunning = mrunning;
}
public String getMdir() {
	return mdir;
}
public void setMdir(String mdir) {
	this.mdir = mdir;
}
public String getMactor() {
	return mactor;
}
public void setMactor(String mactor) {
	this.mactor = mactor;
}
public String getMdate() {
	return mdate;
}
public void setMdate(String mdate) {
	this.mdate = mdate;
}
public String getMstory() {
	return mstory;
}
public void setMstory(String mstory) {
	this.mstory = mstory;
}
public String getMplay() {
	return mplay;
}
public void setMplay(String mplay) {
	this.mplay = mplay;
}
public String getMagecode() {
	return magecode;
}
public void setMagecode(String magecode) {
	this.magecode = magecode;
}
public String getGenno() {
	return genno;
}
public void setGenno(String genno) {
	this.genno = genno;
}



@Override
public String toString() {
	return "Movie [mno=" + mno + ", mname=" + mname + ", mrunning=" + mrunning + ", mdir=" + mdir + ", mactor=" + mactor
			+ ", mdate=" + mdate + ", mstory=" + mstory + ", mplay=" + mplay + ", magecode=" + magecode + ", genno="
			+ genno + ", photo1=" + photo1 + ", photo2=" + photo2 + ", photo3=" + photo3 + ", poster=" + poster
			+ ", agephoto=" + agephoto + "]";
}

}
