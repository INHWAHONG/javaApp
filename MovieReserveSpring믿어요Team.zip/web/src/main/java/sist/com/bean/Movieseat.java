package sist.com.bean;

import java.util.List;

public class Movieseat {
	String sno;
	String sreserve;
	public Movieseat() {
		super();
	}
	public Movieseat(String sno, String sreserve) {
		super();
		this.sno = sno;
		this.sreserve = sreserve;
	}
	public String getSno() {
		return sno;
	}
	public void setSno(String sno) {
		this.sno = sno;
	}
	public String getSreserve() {
		return sreserve;
	}
	public void setSreserve(String sreserve) {
		this.sreserve = sreserve;
	}
	@Override
	public String toString() {
		return "Movieseat [sno=" + sno + ", sreserve=" + sreserve + "]";
	}
	
}
