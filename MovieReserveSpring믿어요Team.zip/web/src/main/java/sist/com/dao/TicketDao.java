package sist.com.dao;


import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import sist.com.bean.Ticket;

public class TicketDao extends SqlSessionDaoSupport {
   
   public   void insertTicket(Ticket ticket) {
         this.getSqlSession().insert("insertTicket",ticket );
   }
   public   List<Ticket> getTicket(String id){
      return this.getSqlSession().selectList("getTicket",id);
   }
   public   String getTicketSeat(int no){
      return this.getSqlSession().selectOne("getTicketSeat",no);
   }
   public   void deleteTicket(int ticketno) {
         this.getSqlSession().delete("deleteTicket", ticketno);
   }
   public   int selectTicketno(Ticket ticket) {
      return this.getSqlSession().selectOne("selectTicketno", ticket);
   }
   public int selectSumPrice(String id) {
	   return this.getSqlSession().selectOne("selectSumPrice", id);
   }
   public Ticket selectTicket(int no) {
	   return this.getSqlSession().selectOne("selectTicket", no);
   }
   public List<Ticket> allTicket(){
	   List<Ticket>list=this.getSqlSession().selectList("allTicket");
	   System.out.println("ttsfdsfsfdsfdsf"+list);
   return list;
   }
   public int allSumPrice() {
	   return this.getSqlSession().selectOne("allSumPrice");
   }
}