package sist.com.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import sist.com.bean.Movieseat;
import sist.com.bean.Ticket;
import sist.com.bean.TlocationBean;

public class SeatDao extends SqlSessionDaoSupport {
  
   public   List<Movieseat> getAllSeat() {
      return this.getSqlSession().selectList("getAllSeat");
   }
   
   public   void updateReserve(String str,Ticket ticket) {
	   String[] split=str.split(" ");
	      ArrayList<String> updateList=new  ArrayList<String>();
	      for(int i=0;i<split.length;i++) {
	         updateList.add(split[i]);
	      }
	      HashMap<String, Object> seatmap=new HashMap<String, Object>();
	      seatmap.put("list", updateList);
	      seatmap.put("ticket", ticket);
	      this.getSqlSession().update("updateReserve", seatmap);
   }
   
   
   public   void eraseReserve(String str,Ticket ticket) {
	   String[] split=str.split(" ");
	      ArrayList<String> updateList=new  ArrayList<String>();
	      ticket.setTdate(ticket.getTdate().substring(0, 10));
	      System.out.println(ticket+" ======== "+str);
	      for(int i=0;i<split.length;i++) {
	         updateList.add(split[i]);
	      }
	      HashMap<String, Object> seatmap=new HashMap<String, Object>();
	      seatmap.put("list", updateList);
	      seatmap.put("ticket", ticket);
	    this.getSqlSession().update("eraseReserve", seatmap);
   }
}