package sist.com.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import java.util.List;
import sist.com.bean.Zipcode;

public class ZipcodeDao extends SqlSessionDaoSupport {

	public List<Zipcode> getDong(String dong) {
		return this.getSqlSession().selectList("getDong", dong);
	}
}
