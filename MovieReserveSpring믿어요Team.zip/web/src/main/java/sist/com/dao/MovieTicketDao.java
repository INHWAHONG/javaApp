package sist.com.dao;

import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;

import sist.com.bean.DayBean;
import sist.com.bean.MovieTicket;
import sist.com.bean.Ticket;

public class MovieTicketDao extends SqlSessionDaoSupport {

	public List<MovieTicket> selectSeat(Ticket ticket){
		return this.getSqlSession().selectList("selectSeat",ticket);
	}
	public List<DayBean> selectDay(){
		return this.getSqlSession().selectList("selectDay");
	}
}
