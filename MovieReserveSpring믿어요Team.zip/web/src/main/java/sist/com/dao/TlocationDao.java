package sist.com.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import sist.com.bean.TlocationBean;

public class TlocationDao extends SqlSessionDaoSupport {
	
	
	public   TlocationBean selectInfo1(int tdeptno) {
		return this.getSqlSession().selectOne("selectInfo1",tdeptno);
	}
	public   List<TlocationBean> selectAll(){
		return this.getSqlSession().selectList("selectAll");
	}
	
}
