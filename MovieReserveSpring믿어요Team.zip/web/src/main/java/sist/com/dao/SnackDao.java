package sist.com.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import sist.com.bean.SnackBean;

public class SnackDao extends SqlSessionDaoSupport {
	

	public   void insertSnack(SnackBean snack) {
			this.getSqlSession().insert("insertSnack", snack);
	}
	
	public   List<SnackBean> selectSnack(HashMap<String, Integer>map){
		return this.getSqlSession().selectList("selectSnack",map);
	}
	public   SnackBean selectOne(int sno) {
		return this.getSqlSession().selectOne("selectOne",sno);
	}
	public   List<SnackBean> selectSnackDept(int sdeptno){
		return this.getSqlSession().selectList("selectSnackDept",sdeptno);
	}
}
