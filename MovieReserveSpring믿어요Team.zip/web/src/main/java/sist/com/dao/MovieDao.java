package sist.com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import sist.com.bean.MnoPoster;
import sist.com.bean.Movie;
import sist.com.bean.SnackBean;

public class MovieDao extends SqlSessionDaoSupport {
	
	public  List<Movie> getMname(){
		return this.getSqlSession().selectList("getMname");
	}
	public  String getMno(String name) {
		String mno=this.getSqlSession().selectOne("getMno", name);
		return mno==null?"null":mno;
	}
    public  String getPhoto1(String mno) {
		return this.getSqlSession().selectOne("getPhoto1", mno);
    }
    public  List<Movie> getMplay(){
    	return this.getSqlSession().selectList("getMplay");
    }
    public  List<MnoPoster> getCurrentMovie(){
    	return this.getSqlSession().selectList("getCurrentMovie");
    }
    public  List<MnoPoster> getPlanMovie(){
    	return this.getSqlSession().selectList("getPlanMovie");
    }
    public  Movie getMovie(String mno){
    	return this.getSqlSession().selectOne("getMovie",mno);
    }
    public  List<Movie> getMovieAge() {
    	return this.getSqlSession().selectList("getMovieAge");
    }
    public  String getSeatPoster(String mname) {
    	return this.getSqlSession().selectOne("getSeatPoster",mname);
    }
}













