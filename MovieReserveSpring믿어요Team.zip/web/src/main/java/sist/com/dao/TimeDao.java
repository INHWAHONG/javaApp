package sist.com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import sist.com.bean.TimeBean;

public class TimeDao extends SqlSessionDaoSupport {
	
	public   List<TimeBean> timeList(){
		return this.getSqlSession().selectList("timeList");
	}
	public   int ticektPrice(String time) {
		return this.getSqlSession().selectOne("ticektPrice",time);
	}
}
