package sist.com.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import sist.com.bean.ReviewBean;

public class ReviewDao extends SqlSessionDaoSupport {
	
    
   public   String getRtitle(int rno) {
	   return this.getSqlSession().selectOne("getRtitle", rno);
   }
   
  
   public   void deleteBoard(String rno) {
			this.getSqlSession().delete("deleteBoard",rno);
   	
   }
    public   void updatemod(ReviewBean board) {
			this.getSqlSession().update("updatemod",board);
    }
    
    public   String getMod(String no) {
    	return this.getSqlSession().selectOne("getMod",no);
    }
    
    public   String getPassword(String rno) {
    	System.out.println(rno);
    	return this.getSqlSession().selectOne("getPassword",rno);
    }
    
    public   List<ReviewBean>selectBoard(HashMap<String, Object>map){
		return this.getSqlSession().selectList("selectBoard",map);
	}
    public   Object selectInfoBoard(int no) {
    	return this.getSqlSession().selectOne("selectInfoBoard",no);
    }
    public   int getTotalRow(HashMap<String,Object> map) {
    	return this.getSqlSession().selectOne("getTotalRow",map);
    }
    public   Integer getSequence() {
    	return this.getSqlSession().selectOne("getSequence");
    }
    
    public   void updateHit(int no) {
			this.getSqlSession().update("updateHit",no);
    	
    }
    public   void updateStep(ReviewBean board) {
    	
			this.getSqlSession().update("updateStep",board);
    }
    	
    
    public   void updateReply(ReviewBean board) {
			this.getSqlSession().update("updateReply",board);
    }
    public   void insertBoard(ReviewBean board) {
			this.getSqlSession().insert("insertBoard",board);
    }
    public   List<ReviewBean>selectRank(){
        return this.getSqlSession().selectList("selectRank");
     }
    public   List<ReviewBean>selectMovieRank(){
        return this.getSqlSession().selectList("selectMovieRank");
     } 
    
}
