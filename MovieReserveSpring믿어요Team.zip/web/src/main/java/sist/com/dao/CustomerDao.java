package sist.com.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import sist.com.bean.Customer;

public class CustomerDao extends SqlSessionDaoSupport {

	public boolean idCheck(String id) {
		String cid = this.getSqlSession().selectOne("idCheck", id);
		return cid == null ? false : true;

	}

	public String selectName(String id) {
		return this.getSqlSession().selectOne("selectName", id);
	}

	public boolean loginCheck(String cid, String pass) {
		String ckpass = this.getSqlSession().selectOne("loginCheck", cid);
		if (ckpass != null && ckpass.equals(pass)) {
			return true;
		}
		return false;

	}

	public void insertCustomer(Customer customer) {
		this.getSqlSession().insert("insertCustomer", customer);
	}
	

	public String idfind(Customer customer) {
		return this.getSqlSession().selectOne("idfind", customer);
	}

	public String findId(Customer customer) {
		return this.getSqlSession().selectOne("findId", customer);
	}

	public String findPw(Customer customer) {
		return this.getSqlSession().selectOne("findPw", customer);
	}

	public void updatePass(HashMap<Object, Object> map) {
		this.getSqlSession().update("updatePass", map);
	}

	public String cLevel(String cid) {
		System.out.println("cid" + cid);
		return this.getSqlSession().selectOne("cLevel", cid);
	}

	public int selectCno(String cid) {
		return this.getSqlSession().selectOne("selectCno", cid);
	}
	
	public void updateCustomer(HashMap<Object, Object> map1) {
		this.getSqlSession().update("updateCustomer", map1);
	}
	public int selectCpoint(String id) {
		return this.getSqlSession().selectOne("selectCpoint", id);
	}
    public List<Customer>customerAll(){
    	List<Customer>list=this.getSqlSession().selectList("customerAll");
    	System.out.println("dgfdgfdgfdg"+list);
      return list;
    }
}