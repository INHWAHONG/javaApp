package sist.com.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import sist.com.bean.ChargeBean;;

public class ChargeDao extends SqlSessionDaoSupport{
	
   public   void insertCharge(ChargeBean charge) {
    this.getSqlSession().insert("insertCharge",charge);
   }
}