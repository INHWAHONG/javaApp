package sist.com.bean;

public class MnoPoster {
	private String mno;
	private String poster;
	public String getMno() {
		return mno;
	}
	public void setMno(String mno) {
		this.mno = mno;
	}
	public String getPoster() {
		return poster;
	}
	public void setPoster(String poster) {
		this.poster = poster;
	}
	@Override
	public String toString() {
		return "MnoPoster [mno=" + mno + ", poster=" + poster + "]";
	}
	public MnoPoster(String mno, String poster) {
		super();
		this.mno = mno;
		this.poster = poster;
	}
	public MnoPoster() {
		super();
	}
	
}
