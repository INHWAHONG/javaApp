package sist.com.bean;

public class ReviewBean {
	
	private int rm;
	private int     no;
	private String title;
	private String writer;
	private String password;
	private String contents;
	private String regdate;
	private int    hit;
	private String fileName;
	private int    ref;           //�׷��ȣ
	private int    step;          //�� �۵��� ����
	private int    lev;
	private int    pnum;         //�θ��ȣ
	private int    reply;        // ��۰���
	
	private String job;
	




    private int rno;
    private String rname;
    private String rtitle;
    private String rpassword;
    private String rscore;
    private String mtitle;
    private String rstory;
	private String cid;
	private String mno;
	
	
	
	  public String getMno() {
		return mno;
	}


	public void setMno(String mno) {
		this.mno = mno;
	}


	public String getCid() {
		return cid;
	}


	public void setCid(String cid) {
		this.cid = cid;
	}


	public ReviewBean() {
	    	 super();
	     }
	
	  
	public ReviewBean(int pnum, String job) {
		super();
		this.pnum = pnum;
		this.job = job;
	}


	public String getJob() {
		return job;
	}


	public void setJob(String job) {
		this.job = job;
	}


	public int getRm() {
		return rm;
	}


	public void setRm(int rm) {
		this.rm = rm;
	}


	public int getNo() {
		return no;
	}



	public void setNo(int no) {
		this.no = no;
	}



	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public String getWriter() {
		return writer;
	}



	public void setWriter(String writer) {
		this.writer = writer;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getContents() {
		return contents;
	}



	public void setContents(String contents) {
		this.contents = contents;
	}



	public String getRegdate() {
		return regdate;
	}



	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}



	public int getHit() {
		return hit;
	}



	public void setHit(int hit) {
		this.hit = hit;
	}



	public String getFileName() {
		return fileName;
	}



	public void setFileName(String fileName) {
		this.fileName = fileName;
	}



	public int getRef() {
		return ref;
	}



	public void setRef(int ref) {
		this.ref = ref;
	}



	public int getStep() {
		return step;
	}



	public void setStep(int step) {
		this.step = step;
	}



	public int getLev() {
		return lev;
	}



	public void setLev(int lev) {
		this.lev = lev;
	}



	public int getPnum() {
		return pnum;
	}



	public void setPnum(int pnum) {
		this.pnum = pnum;
	}



	public int getReply() {
		return reply;
	}



	public void setReply(int reply) {
		this.reply = reply;
	}


	

	


	public ReviewBean(int rm, int no, String title, String writer, String password, String contents, String regdate,
			int hit, String fileName, int ref, int step, int lev, int pnum, int reply, String job, int rno,
			String rname, String rtitle, String rpassword, String rscore, String mtitle, String rstory, String cid,
			String mno) {
		super();
		this.rm = rm;
		this.no = no;
		this.title = title;
		this.writer = writer;
		this.password = password;
		this.contents = contents;
		this.regdate = regdate;
		this.hit = hit;
		this.fileName = fileName;
		this.ref = ref;
		this.step = step;
		this.lev = lev;
		this.pnum = pnum;
		this.reply = reply;
		this.job = job;
		this.rno = rno;
		this.rname = rname;
		this.rtitle = rtitle;
		this.rpassword = rpassword;
		this.rscore = rscore;
		this.mtitle = mtitle;
		this.rstory = rstory;
		this.cid = cid;
		this.mno = mno;
	}


	public int getRno() {
		return rno;
	}


	public void setRno(int rno) {
		this.rno = rno;
	}


	public String getRname() {
		return rname;
	}


	public void setRname(String rname) {
		this.rname = rname;
	}


	public String getRtitle() {
		return rtitle;
	}


	public void setRtitle(String rtitle) {
		this.rtitle = rtitle;
	}


	public String getRpassword() {
		return rpassword;
	}


	public void setRpassword(String rpassword) {
		this.rpassword = rpassword;
	}


	public String getRscore() {
		return rscore;
	}


	public void setRscore(String rscore) {
		this.rscore = rscore;
	}


	public String getMtitle() {
		return mtitle;
	}


	public void setMtitle(String mtitle) {
		this.mtitle = mtitle;
	}


	public String getRstory() {
		return rstory;
	}


	public void setRstory(String rstory) {
		this.rstory = rstory;
	}


	@Override
	public String toString() {
		return "ReviewBean [rm=" + rm + ", no=" + no + ", title=" + title + ", writer=" + writer + ", password="
				+ password + ", contents=" + contents + ", regdate=" + regdate + ", hit=" + hit + ", fileName="
				+ fileName + ", ref=" + ref + ", step=" + step + ", lev=" + lev + ", pnum=" + pnum + ", reply=" + reply
				+ ", job=" + job + ", rno=" + rno + ", rname=" + rname + ", rtitle=" + rtitle + ", rpassword="
				+ rpassword + ", rscore=" + rscore + ", mtitle=" + mtitle + ", rstory=" + rstory + ", cid=" + cid
				+ ", mno=" + mno + "]";
	}


}
