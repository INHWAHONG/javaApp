package sist.com.bean;

public class Customer {
private int    cno;
private String cid;
private String cphone;
private String caddress;
private String cname;
private String cpassword;
private String cemail;
private String cjang;
private int    cpoint;
private String cbirth;
private String cgender;
private String clevel;
private String cjoindate;
public Customer(int cno, String cid, String cphone, String caddress, String cname, String cpassword, String cemail,
      String cjang, int cpoint, String cbirth, String cgender, String clevel, String cjoindate) {
   super();
   this.cno = cno;
   this.cid = cid;
   this.cphone = cphone;
   this.caddress = caddress;
   this.cname = cname;
   this.cpassword = cpassword;
   this.cemail = cemail;
   this.cjang = cjang;
   this.cpoint = cpoint;
   this.cbirth = cbirth;
   this.cgender = cgender;
   this.clevel = clevel;
   this.cjoindate = cjoindate;
}
public Customer() {
   super();
}
public int getCno() {
   return cno;
}
public void setCno(int cno) {
   this.cno = cno;
}
public String getCid() {
   return cid;
}
public void setCid(String cid) {
   this.cid = cid;
}
public String getCphone() {
   return cphone;
}
public void setCphone(String cphone) {
   this.cphone = cphone;
}
public String getCaddress() {
   return caddress;
}
public void setCaddress(String caddress) {
   this.caddress = caddress;
}
public String getCname() {
   return cname;
}
public void setCname(String cname) {
   this.cname = cname;
}
public String getCpassword() {
   return cpassword;
}
public void setCpassword(String cpassword) {
   this.cpassword = cpassword;
}
public String getCemail() {
   return cemail;
}
public void setCemail(String cemail) {
   this.cemail = cemail;
}
public String getCjang() {
   return cjang;
}
public void setCjang(String cjang) {
   this.cjang = cjang;
}
public int getCpoint() {
   return cpoint;
}
public void setCpoint(int cpoint) {
   this.cpoint = cpoint;
}
public String getCbirth() {
   return cbirth;
}
public void setCbirth(String cbirth) {
   this.cbirth = cbirth;
}
public String getCgender() {
   return cgender;
}
public void setCgender(String cgender) {
   this.cgender = cgender;
}
public String getClevel() {
   return clevel;
}
public void setClevel(String clevel) {
   this.clevel = clevel;
}
public String getCjoindate() {
   return cjoindate;
}
public void setCjoindate(String cjoindate) {
   this.cjoindate = cjoindate;
}
@Override
public String toString() {
   return "Customer [cno=" + cno + ", cid=" + cid + ", cphone=" + cphone + ", caddress=" + caddress + ", cname="
         + cname + ", cpassword=" + cpassword + ", cemail=" + cemail + ", cjang=" + cjang + ", cpoint=" + cpoint
         + ", cbirth=" + cbirth + ", cgender=" + cgender + ", clevel=" + clevel + ", cjoindate=" + cjoindate + "]";
}


}