package sist.com.bean;

public class TlocationBean {
	private int tdeptno;
	private String tphoto;
	private String tloc;
	private String taddress;
	private String ttel;
	private String tmapx;
	private String tmapy;
	private String tparking;
	public int getTdeptno() {
		return tdeptno;
	}
	public void setTdeptno(int tdeptno) {
		this.tdeptno = tdeptno;
	}
	public String getTphoto() {
		return tphoto;
	}
	public void setTphoto(String tphoto) {
		this.tphoto = tphoto;
	}
	public String getTloc() {
		return tloc;
	}
	public void setTloc(String tloc) {
		this.tloc = tloc;
	}
	public String getTaddress() {
		return taddress;
	}
	public void setTaddress(String taddress) {
		this.taddress = taddress;
	}
	public String getTtel() {
		return ttel;
	}
	public void setTtel(String ttel) {
		this.ttel = ttel;
	}
	public String getTmapx() {
		return tmapx;
	}
	public void setTmapx(String tmapx) {
		this.tmapx = tmapx;
	}
	public String getTmapy() {
		return tmapy;
	}
	public void setTmapy(String tmapy) {
		this.tmapy = tmapy;
	}
	public String getTparking() {
		return tparking;
	}
	public void setTparking(String tparking) {
		this.tparking = tparking;
	}
	@Override
	public String toString() {
		return "TlocationBean [tdeptno=" + tdeptno + ", tphoto=" + tphoto + ", tloc=" + tloc + ", taddress=" + taddress
				+ ", ttel=" + ttel + ", tmapx=" + tmapx + ", tmapy=" + tmapy + ", tparking=" + tparking + "]";
	}
	

	
	
}
