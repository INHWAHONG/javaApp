package sist.com.bean;

public class ChargeBean {
private int ticketno;
private int cno;


public ChargeBean() {
   super();
}
public ChargeBean(int ticketno, int cno) {
   super();
   this.ticketno = ticketno;
   this.cno = cno;
}
public int getTicketno() {
   return ticketno;
}
public void setTicketno(int ticketno) {
   this.ticketno = ticketno;
}
public int getCno() {
   return cno;
}
public void setCno(int cno) {
   this.cno = cno;
}
@Override
public String toString() {
   return "Charge [ticketno=" + ticketno + ", cno=" + cno + "]";
}


}