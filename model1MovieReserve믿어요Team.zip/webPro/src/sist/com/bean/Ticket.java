package sist.com.bean;

public class Ticket {
int no;
String id;
String title;
String seat;
String theater;
String tdate;
String time;
String today;
public int getNo() {
	return no;
}
public void setNo(int no) {
	this.no = no;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getSeat() {
	return seat;
}
public void setSeat(String seat) {
	this.seat = seat;
}
public String getTheater() {
	return theater;
}
public void setTheater(String theater) {
	this.theater = theater;
}
public String getTdate() {
	return tdate;
}
public void setTdate(String tdate) {
	this.tdate = tdate;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getToday() {
	return today;
}
public void setToday(String today) {
	this.today = today;
}
public Ticket(int no, String id, String title, String seat, String theater, String tdate, String time, String today) {
	super();
	this.no = no;
	this.id = id;
	this.title = title;
	this.seat = seat;
	this.theater = theater;
	this.tdate = tdate;
	this.time = time;
	this.today = today;
}
public Ticket() {
	super();
}
@Override
public String toString() {
	return "Ticket [no=" + no + ", id=" + id + ", title=" + title + ", seat=" + seat + ", theater=" + theater
			+ ", tdate=" + tdate + ", time=" + time + ", today=" + today + "]";
}



}
