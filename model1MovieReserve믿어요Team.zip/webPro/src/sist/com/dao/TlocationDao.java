package sist.com.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;

import sist.com.bean.TlocationBean;

public class TlocationDao {
	private static SqlSessionFactory sqlSessionFactory;
	static {
		sqlSessionFactory=SqlSessionFactoryManger.getSqlSessionFactory();		
	}
	
	public static TlocationBean selectInfo1(int tdeptno) {
		return sqlSessionFactory.openSession().selectOne("selectInfo1",tdeptno);
	}
	public static List<TlocationBean> selectAll(){
		return sqlSessionFactory.openSession().selectList("selectAll");
	}
	
}
