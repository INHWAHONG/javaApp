package sist.com.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import sist.com.bean.ReviewBean;

public class ReviewDao {
	private static SqlSessionFactory sqlSessionFactory;
    static {
    	 sqlSessionFactory=SqlSessionFactoryManger.getSqlSessionFactory();
    }
    
   public static String getRtitle(int rno) {
	   return sqlSessionFactory.openSession().selectOne("getRtitle", rno);
   }
   
  
     
   public static void deleteBoard(String rno) {
   	SqlSession sqlSession=null;
   	try {
			sqlSession=sqlSessionFactory.openSession();
			sqlSession.delete("deleteBoard",rno);
			sqlSession.commit();
			
		} catch (Exception e) {
			// TODO: handle exception\
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
   	
   }
    public static void updatemod(ReviewBean board) {
    	SqlSession sqlSession=null;
    	try {
			sqlSession=sqlSessionFactory.openSession();
			sqlSession.update("updatemod",board);
			sqlSession.commit();
			
		} catch (Exception e) {
			// TODO: handle exception\
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
    }
    
    public static String getMod(String no) {
    	return sqlSessionFactory.openSession().selectOne("getMod",no);
    }
    
    public static String getPassword(String rno) {
    	System.out.println(rno);
    	return sqlSessionFactory.openSession().selectOne("getPassword",rno);
    }
    
    public static List<ReviewBean>selectBoard(HashMap<String, Object>map){
		return sqlSessionFactory.openSession().selectList("selectBoard",map);
	}
    public static Object selectInfoBoard(int no) {
    	return sqlSessionFactory.openSession().selectOne("selectInfoBoard",no);
    }
    public static int getTotalRow(HashMap<String,Object> map) {
    	return sqlSessionFactory.openSession().selectOne("getTotalRow",map);
    }
    public static Integer getSequence() {
    	return sqlSessionFactory.openSession().selectOne("getSequence");
    }
    
    public static void updateHit(int no) {
    	SqlSession sqlSession=null;
    	try {
			sqlSession=sqlSessionFactory.openSession();
			sqlSession.update("updateHit",no);
			sqlSession.commit();
			
		} catch (Exception e) {
			// TODO: handle exception\
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
    	
    }
    public static void updateStep(ReviewBean board) {
    	
    	SqlSession sqlSession=null;
    	try {
			sqlSession=sqlSessionFactory.openSession();
			sqlSession.update("updateStep",board);
			sqlSession.commit();
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			sqlSession.close();
		}
    }
    	
    
    public static void updateReply(ReviewBean board) {
    	SqlSession sqlSession=null;
    	try {
			sqlSession=sqlSessionFactory.openSession();
			sqlSession.update("updateReply",board);
			sqlSession.commit();
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			sqlSession.close();
		}
    }
    public static void insertBoard(ReviewBean board) {
    	SqlSession sqlSession=null;
    	try {
			sqlSession=sqlSessionFactory.openSession();
			sqlSession.insert("insertBoard",board);
			sqlSession.commit();
			
		} catch (Exception e) {
			// TODO: handle exception\
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
    }
    public static List<ReviewBean>selectRank(){
        return sqlSessionFactory.openSession().selectList("selectRank");
     }
    public static List<ReviewBean>selectMovieRank(){
        return sqlSessionFactory.openSession().selectList("selectMovieRank");
     } 
    
}
