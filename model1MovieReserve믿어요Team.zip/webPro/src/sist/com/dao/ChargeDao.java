package sist.com.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import sist.com.bean.ChargeBean;;

public class ChargeDao {
   private static SqlSessionFactory sqlSessionFactory;
   static {
      sqlSessionFactory=SqlSessionFactoryManger.getSqlSessionFactory();      
   }
   public static void insertCharge(ChargeBean charge) {
      SqlSession sqlSession=null;
      try {
         sqlSession=sqlSessionFactory.openSession();
         sqlSession.insert("insertCharge", charge);
         sqlSession.commit();
      } catch (Exception e) {
         // TODO: handle exception
         e.printStackTrace();
      }finally {
         sqlSession.close();
      }
   }
}