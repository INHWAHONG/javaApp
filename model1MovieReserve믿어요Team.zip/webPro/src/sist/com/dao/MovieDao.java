package sist.com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import sist.com.bean.MnoPoster;
import sist.com.bean.Movie;
import sist.com.bean.SnackBean;

public class MovieDao {
	private static SqlSessionFactory sqlSessionFactory;
	static {
		sqlSessionFactory=SqlSessionFactoryManger.getSqlSessionFactory();		
	}
	public static List<String> getMname(){
		return sqlSessionFactory.openSession().selectList("getMname");
	}
	public static String getMno(String name) {
		String mno=sqlSessionFactory.openSession().selectOne("getMno", name);
		return mno==null?"null":mno;
	}
    public static String getPhoto1(String mno) {
		return sqlSessionFactory.openSession().selectOne("getPhoto1", mno);
    }
    public static List<String> getMplay(){
    	return sqlSessionFactory.openSession().selectList("getMplay");
    }
    public static List<MnoPoster> getCurrentMovie(){
    	return sqlSessionFactory.openSession().selectList("getCurrentMovie");
    }
    public static List<MnoPoster> getPlanMovie(){
    	return sqlSessionFactory.openSession().selectList("getPlanMovie");
    }
    public static List<Movie> getMovie(String mno){
    	return sqlSessionFactory.openSession().selectList("getMovie",mno);
    }
    public static List<Movie> getMovieAge() {
    	return sqlSessionFactory.openSession().selectList("getMovieAge");
    }
    public static String getSeatPoster(String mname) {
    	return sqlSessionFactory.openSession().selectOne("getSeatPoster",mname);
    }
}













