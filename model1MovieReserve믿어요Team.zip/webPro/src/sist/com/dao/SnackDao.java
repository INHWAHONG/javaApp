package sist.com.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import sist.com.bean.SnackBean;

public class SnackDao {
	private static SqlSessionFactory sqlSessionFactory;
	static {
		sqlSessionFactory = SqlSessionFactoryManger.getSqlSessionFactory();
	}

	public static void insertSnack(SnackBean snack) {
		SqlSession sqlSession = null;
		try {
			sqlSession = sqlSessionFactory.openSession();
			sqlSession.insert("insertSnack", snack);
			sqlSession.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			if (sqlSession != null) {
				sqlSession.close();
			}
		}
	}
	
	public static List<SnackBean> selectSnack(){
		return sqlSessionFactory.openSession().selectList("selectSnack");
	}
	public static SnackBean selectOne(int sno) {
		return sqlSessionFactory.openSession().selectOne("selectOne",sno);
	}
	public static List<SnackBean> selectSnackDept(int sdeptno){
		return sqlSessionFactory.openSession().selectList("selectSnackDept",sdeptno);
	}
}
