package sist.com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;

import sist.com.bean.TimeBean;

public class TimeDao {
	private static SqlSessionFactory sqlSessionFactory;
	static {
		sqlSessionFactory = SqlSessionFactoryManger.getSqlSessionFactory();
	}
	public static List<TimeBean> timeList(){
		return sqlSessionFactory.openSession().selectList("timeList");
	}
	public static int ticektPrice(String time) {
		return sqlSessionFactory.openSession().selectOne("ticektPrice",time);
	}
}
