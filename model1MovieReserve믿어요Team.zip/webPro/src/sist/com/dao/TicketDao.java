package sist.com.dao;


import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import sist.com.bean.Ticket;

public class TicketDao {
   private static SqlSessionFactory sqlSessionFactory;
   static {
      sqlSessionFactory=SqlSessionFactoryManger.getSqlSessionFactory();      
   }
   
   public static void insertTicket(Ticket ticket) {
      SqlSession sqlSession=null;
      System.out.println("insetticket");
      try {
         sqlSession=sqlSessionFactory.openSession();
         sqlSession.insert("insertTicket",ticket );
         sqlSession.commit();         
                  
      } catch (Exception e) {
         // TODO: handle exception
         e.printStackTrace();
      }finally {
         sqlSession.close();
      }
      
   }
   public static List<Ticket> getTicket(String id){
      return sqlSessionFactory.openSession().selectList("getTicket",id);
   }
   public static String getTicketSeat(int no){
      return sqlSessionFactory.openSession().selectOne("getTicketSeat",no);
   }
   public static void deleteTicket(int ticketno) {
      SqlSession sqlSession=null;
      try {
         sqlSession=sqlSessionFactory.openSession();
         sqlSession.delete("deleteTicket", ticketno);
         sqlSession.commit();         
         }catch (Exception e) {
         // TODO: handle exception
         e.printStackTrace();
      }finally {
         sqlSession.close();
      }
   }
   public static int selectTicketno(Ticket ticket) {
      return sqlSessionFactory.openSession().selectOne("selectTicketno", ticket);
   }
   
}