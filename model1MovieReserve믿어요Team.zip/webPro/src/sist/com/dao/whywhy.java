package sist.com.dao;

public class whywhy {
	public static void main(String[] args) {
		
		String idname=null;
		String idname2="";
		String idname3="no";
		String idname4="null";
		
		   if (idname==null||idname=="null"||idname==""||idname=="no") {
         	  System.out.println("if1");
		   }else{
			   System.out.println("else1");
		   }
		   if (idname2==null||idname2=="null"||idname2==""||idname2=="no") {
			   System.out.println("if2");
		   }else{
			   System.out.println("else2");
		   }
		   if (idname3==null||idname3=="null"||idname3==""||idname3=="no") {
			   System.out.println("if3");
		   }else{
			   System.out.println("else3");
		   }
		   if (idname4==null||idname4=="null"||idname4==""||idname4=="no") {
			   System.out.println("if4");
		   }else{
			   System.out.println("else4");
		   }
	}
}
