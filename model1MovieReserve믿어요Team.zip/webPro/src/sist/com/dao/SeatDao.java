package sist.com.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import sist.com.bean.Movieseat;
import sist.com.bean.TlocationBean;

public class SeatDao {
   private static SqlSessionFactory sqlSessionFactory;
   static {
      sqlSessionFactory=SqlSessionFactoryManger.getSqlSessionFactory();      
   }
   
   public static List<Movieseat> getAllSeat() {
      return sqlSessionFactory.openSession().selectList("getAllSeat");
   }
   public static void updateReserve(String str) {
      SqlSession sqlSession=null;
      System.out.println("str"+str);
      String[] split=str.split(" ");
      ArrayList<String> updateList=new  ArrayList<String>();
      for(int i=0;i<split.length;i++) {
    	  updateList.add(split[i]);
      }
     
      HashMap<String, ArrayList<String>> seatmap=new HashMap<String, ArrayList<String>>();
      seatmap.put("list", updateList);
      try {
         sqlSession=sqlSessionFactory.openSession();
         sqlSession.update("updateReserve", seatmap);
         sqlSession.commit();         
      }catch (Exception e2) {
         // TODO: handle exception
         e2.printStackTrace();
      }finally {
         sqlSession.close();
      }
   }
   
   public static void eraseReserve(String str) {
	   SqlSession sqlSession=null;
	      System.out.println("str"+str);
	      String[] split=str.split(" ");
	      ArrayList<String> eraseList=new  ArrayList<String>();
	      for(int i=0;i<split.length;i++) {
	    	  eraseList.add(split[i]);
	      }
	     
	      HashMap<String, ArrayList<String>> seatmap=new HashMap<String, ArrayList<String>>();
	      seatmap.put("list", eraseList);
	      try {
	         sqlSession=sqlSessionFactory.openSession();
	         sqlSession.update("eraseReserve", seatmap);
	         sqlSession.commit();         
	      }catch (Exception e2) {
	         // TODO: handle exception
	         e2.printStackTrace();
	      }finally {
	         sqlSession.close();
	      }
   }
}