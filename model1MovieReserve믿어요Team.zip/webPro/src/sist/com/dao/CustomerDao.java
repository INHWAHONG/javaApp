package sist.com.dao;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import sist.com.bean.Customer;

public class CustomerDao {
   private static SqlSessionFactory sqlSessionFactory;
   static {
      sqlSessionFactory = SqlSessionFactoryManger.getSqlSessionFactory(); // �������� Ŭ������ �����پ�
   }
   

   public static boolean idCheck(String id) {
      String cid=sqlSessionFactory.openSession().selectOne("idCheck", id);
      return cid==null?false:true;
   
   }
   public static String selectName(String id) {
      return sqlSessionFactory.openSession().selectOne("selectName",id);
   }
   public static boolean loginCheck(String cid,String pass) {
      String ckpass = sqlSessionFactory.openSession().selectOne("loginCheck", cid);
      if(ckpass!=null&&ckpass.equals(pass)) {
         return true;
      }
      return false;
      
   }
   public static void insertCustomer(Customer customer) {
      SqlSession sqlSession=null;
      try {
         sqlSession=sqlSessionFactory.openSession();
         sqlSession.insert("insertCustomer", customer);
         sqlSession.commit();
      } catch (Exception e) {
         // TODO: handle exception
         e.printStackTrace();
      }finally {
         if(sqlSession!=null) {
         sqlSession.close();
         }
   }
}
   public static String idfind(Customer customer) {
      return sqlSessionFactory.openSession().selectOne("idfind", customer);
   }
   public static String findId(Customer customer) {
      return sqlSessionFactory.openSession().selectOne("findId", customer);
   }

public static String findPw(Customer customer) {
      return sqlSessionFactory.openSession().selectOne("findPw",customer);
   }

public static void updatePass(HashMap<Object, Object>map) {
      SqlSession sqlSession=null;
      try {
         sqlSession=sqlSessionFactory.openSession();
         sqlSession.update("updatePass",map);
         sqlSession.commit();
      } catch (Exception e) {
         // TODO: handle exception
         e.printStackTrace();
      }finally {
         if(sqlSession!=null) {
         sqlSession.close();
         }
   }
   }
public static String cLevel(String cid) {
	System.out.println("cid"+cid);
    return sqlSessionFactory.openSession().selectOne("cLevel",cid);
 }
public static int selectCno(String cid) {
   return sqlSessionFactory.openSession().selectOne("selectCno", cid);
}
}