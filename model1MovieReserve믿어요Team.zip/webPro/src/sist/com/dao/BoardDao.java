package sist.com.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import sist.com.bean.Board;

public class BoardDao {
	private static SqlSessionFactory sqlSessionFactory;
	static {
		sqlSessionFactory=SqlSessionFactoryManger.getSqlSessionFactory();		
	}
	
	public static List<Board>selectBoard(HashMap<String, Object>map){
		return sqlSessionFactory.openSession().selectList("selectBoard",map);
	}
	
	public static Object selectInfoBoard(int no) {
		return sqlSessionFactory.openSession().selectOne("selectInfoBoard", no);
	}
	public static int getTotalRow(HashMap<String, Object>map) {
		return sqlSessionFactory.openSession().selectOne("getTotalRow",map);
	}
	public static Integer getSequence() {
		return sqlSessionFactory.openSession().selectOne("getSequence");
	}
	public static void updateHit(int no) {
		SqlSession sqlSession=null;
		try {
			sqlSession=sqlSessionFactory.openSession();
			sqlSession.update("updateHit", no);
			sqlSession.commit();			
						
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}

		
	}
	public static String getPassWord(int no) {
		return sqlSessionFactory.openSession().selectOne("getPassWord", no); 
	}
	public static void updateStep(Board board) {
		SqlSession sqlSession=null;
		try {
			sqlSession=sqlSessionFactory.openSession();
			sqlSession.update("updateStep",board);
			sqlSession.commit();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		
	}
	public static void deleteBoard(int no) {
		SqlSession sqlSession=null;
		try {
			sqlSession=sqlSessionFactory.openSession();
			sqlSession.delete("deleteBoard", no);
			sqlSession.commit();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
	}
	public static void upateReply(Board board) {
		SqlSession sqlSession=null;
		try {
			sqlSession=sqlSessionFactory.openSession();
			sqlSession.update("upateReply",board);
			sqlSession.commit();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		
	}
	public static void insertBoard(Board board) {
		SqlSession sqlSession=null;
		try {
			sqlSession=sqlSessionFactory.openSession();
			sqlSession.insert("insertBoard",board );
			sqlSession.commit();			
						
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		
	}

}








